package com.ilauncher.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * Siyah Dynamic Island hapini TUM uygulamalarin ustunde gosterir ve sarj takilinca acar.
 * Servis acik kaldigi icin launcher islemi de arka planda oldurulmez (eski ekrana donme azalir).
 */
public class PillService extends Service {
    private static final String CHANNEL = "ilauncher_pill";
    static PillService instance;

    private WindowManager wm;
    private IslandView island;
    private boolean suppressed;
    private boolean attached;

    private final BroadcastReceiver battery = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent i) {
            apply(i);
        }
    };

    static void start(Context c) {
        try {
            if (!Settings.canDrawOverlays(c)) {
                return;
            }
            Intent i = new Intent(c, PillService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Launcher ekrandayken kendi adasi var; bu hapi gizler. */
    static void suppress(boolean s) {
        PillService p = instance;
        if (p != null) {
            p.setSuppressed(s);
        }
    }

    private void setSuppressed(boolean s) {
        suppressed = s;
        if (island != null) {
            island.setVisibility(s ? View.INVISIBLE : View.VISIBLE);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        startInForeground();
        addPill();
        Intent sticky = registerReceiver(battery, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) {
            apply(sticky);
        }
    }

    private void startInForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Dynamic Island",
                        NotificationManager.IMPORTANCE_MIN));
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CHANNEL)
                    : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setContentTitle("Dynamic Island etkin")
                    .setOngoing(true);
            startForeground(1, b.build());
        } catch (Throwable ignored) {
        }
    }

    private void addPill() {
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            island = new IslandView(this);
            float d = getResources().getDisplayMetrics().density;
            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    Math.round(230 * d), Math.round(60 * d), type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            } else if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(island, lp);
            attached = true;
            island.setVisibility(suppressed ? View.INVISIBLE : View.VISIBLE);
        } catch (Throwable t) {
            attached = false;
        }
    }

    private void apply(Intent i) {
        if (island == null) {
            return;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
        island.setBattery(pct, charging);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        try {
            unregisterReceiver(battery);
        } catch (Throwable ignored) {
        }
        try {
            if (attached && wm != null && island != null) {
                wm.removeView(island);
            }
        } catch (Throwable ignored) {
        }
    }
}
