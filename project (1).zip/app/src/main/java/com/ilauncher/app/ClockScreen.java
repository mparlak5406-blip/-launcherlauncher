package com.ilauncher.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** iPhone tarzi Saat: Dunya Saati, Kronometre, Zamanlayici. */
final class ClockScreen extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int ORANGE = 0xFFFF9F0A;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final FrameLayout pages;
    private final View[] tabViews = new View[3];
    private final TextView[] tabLabels = new TextView[3];
    private int tab;

    // dunya saati
    private final AnalogView analog;
    private final LinearLayout cityList;
    private final String[][] cities = {
            {"Türkiye", "Europe/Istanbul"}, {"Londra", "Europe/London"}, {"Berlin", "Europe/Berlin"},
            {"Dubai", "Asia/Dubai"}, {"Tokyo", "Asia/Tokyo"}, {"New York", "America/New_York"},
            {"Los Angeles", "America/Los_Angeles"}
    };
    private final TextView[] cityTimes = new TextView[cities.length];

    // kronometre
    private final TextView swText;
    private final TextView swLeft;
    private final TextView swRight;
    private final LinearLayout lapList;
    private boolean swRunning;
    private long swBase;
    private long swAccum;
    private long lastLap;
    private int lapCount;

    // zamanlayici
    private final TextView tmText;
    private final TextView tmButton;
    private final TextView tmHint;
    private boolean tmRunning;
    private long tmEnd;
    private int tmMinutes = 5;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 40);
        }
    };

    ClockScreen(Context c, Host h) {
        super(c, h);
        setBackgroundColor(Color.BLACK);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(52), 0, dp(34) + host.bottomInset());
        addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        pages = new FrameLayout(c);
        col.addView(pages, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---- Dunya saati
        ScrollView ws = new ScrollView(c);
        ws.setVerticalScrollBarEnabled(false);
        LinearLayout wl = new LinearLayout(c);
        wl.setOrientation(LinearLayout.VERTICAL);
        wl.setGravity(Gravity.CENTER_HORIZONTAL);
        wl.setPadding(dp(20), dp(8), dp(20), dp(16));
        analog = new AnalogView(c);
        wl.addView(analog, new LinearLayout.LayoutParams(dp(230), dp(230)));
        cityList = new LinearLayout(c);
        cityList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(MATCH, WRAP);
        cl.topMargin = dp(18);
        wl.addView(cityList, cl);
        for (int i = 0; i < cities.length; i++) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(12), 0, dp(12));
            LinearLayout left = new LinearLayout(c);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(tv(c, cities[i][0], 20f, Color.WHITE, false));
            left.addView(tv(c, offsetText(cities[i][1]), 13f, 0xFF8E8E93, false));
            row.addView(left, new LinearLayout.LayoutParams(0, WRAP, 1f));
            cityTimes[i] = tv(c, "", 34f, Color.WHITE, false);
            cityTimes[i].setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            row.addView(cityTimes[i], new LinearLayout.LayoutParams(WRAP, WRAP));
            cityList.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
            View line = new View(c);
            line.setBackgroundColor(0xFF2C2C2E);
            cityList.addView(line, new LinearLayout.LayoutParams(MATCH, 1));
        }
        ws.addView(wl, new ViewGroup.LayoutParams(MATCH, WRAP));
        tabViews[0] = ws;

        // ---- Kronometre
        LinearLayout sw = new LinearLayout(c);
        sw.setOrientation(LinearLayout.VERTICAL);
        sw.setGravity(Gravity.CENTER_HORIZONTAL);
        swText = tv(c, "00:00,00", 72f, Color.WHITE, false);
        swText.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        swText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(MATCH, WRAP);
        st.topMargin = dp(60);
        sw.addView(swText, st);
        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER);
        swLeft = circle(c, "Sıfırla", 0xFF333333, 0xFFFFFFFF);
        swRight = circle(c, "Başlat", 0xFF0E3B1A, 0xFF30D158);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(84), dp(84));
        bl.leftMargin = dp(28);
        bl.rightMargin = dp(28);
        btns.addView(swLeft, bl);
        btns.addView(swRight, bl);
        LinearLayout.LayoutParams bll = new LinearLayout.LayoutParams(MATCH, WRAP);
        bll.topMargin = dp(36);
        sw.addView(btns, bll);
        ScrollView ls = new ScrollView(c);
        ls.setVerticalScrollBarEnabled(false);
        lapList = new LinearLayout(c);
        lapList.setOrientation(LinearLayout.VERTICAL);
        lapList.setPadding(dp(24), dp(10), dp(24), 0);
        ls.addView(lapList, new ViewGroup.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams lsl = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        lsl.topMargin = dp(18);
        sw.addView(ls, lsl);
        tabViews[1] = sw;
        swLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                swLeftTap();
            }
        });
        swRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                swRightTap();
            }
        });

        // ---- Zamanlayici
        LinearLayout tm = new LinearLayout(c);
        tm.setOrientation(LinearLayout.VERTICAL);
        tm.setGravity(Gravity.CENTER_HORIZONTAL);
        tmText = tv(c, "5:00", 84f, Color.WHITE, false);
        tmText.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        tmText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tt = new LinearLayout.LayoutParams(MATCH, WRAP);
        tt.topMargin = dp(70);
        tm.addView(tmText, tt);
        tmHint = tv(c, "dakika", 16f, 0xFF8E8E93, false);
        tmHint.setGravity(Gravity.CENTER);
        tm.addView(tmHint, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout pm = new LinearLayout(c);
        pm.setOrientation(LinearLayout.HORIZONTAL);
        pm.setGravity(Gravity.CENTER);
        TextView minus = circle(c, "−", 0xFF333333, Color.WHITE);
        TextView plus = circle(c, "+", 0xFF333333, Color.WHITE);
        minus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f);
        plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(72), dp(72));
        pl.leftMargin = dp(24);
        pl.rightMargin = dp(24);
        pm.addView(minus, pl);
        pm.addView(plus, pl);
        LinearLayout.LayoutParams pml = new LinearLayout.LayoutParams(MATCH, WRAP);
        pml.topMargin = dp(40);
        tm.addView(pm, pml);
        tmButton = circle(c, "Başlat", 0xFF0E3B1A, 0xFF30D158);
        LinearLayout.LayoutParams tbl = new LinearLayout.LayoutParams(dp(96), dp(96));
        tbl.topMargin = dp(40);
        tm.addView(tmButton, tbl);
        tabViews[2] = tm;
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tmRunning && tmMinutes > 1) {
                    tmMinutes--;
                    update();
                }
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tmRunning && tmMinutes < 180) {
                    tmMinutes++;
                    update();
                }
            }
        });
        tmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tmRunning) {
                    tmRunning = false;
                } else {
                    tmRunning = true;
                    tmEnd = SystemClock.elapsedRealtime() + tmMinutes * 60000L;
                }
                update();
            }
        });

        for (View v : tabViews) {
            pages.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        }

        // ---- sekmeler
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0xFF1C1C1E);
        String[] names = {"Dünya Saati", "Kronometre", "Zamanlayıcı"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = tv(c, names[i], 13f, 0xFF8E8E93, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(14), 0, dp(14));
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(idx);
                }
            });
            tabLabels[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        col.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        select(0);
        addHomeBar(true);
    }

    @Override
    boolean darkStatus() {
        return false;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(tick);
    }

    // ------------------------------------------------------------------ yardimcilar

    private TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private TextView circle(Context c, String s, int fill, int color) {
        TextView t = tv(c, s, 16f, color, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        t.setBackground(g);
        return t;
    }

    private void tint(TextView t, int fill, int color, String s) {
        t.setText(s);
        t.setTextColor(color);
        ((GradientDrawable) t.getBackground()).setColor(fill);
    }

    private void select(int i) {
        tab = i;
        for (int k = 0; k < 3; k++) {
            tabViews[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            tabLabels[k].setTextColor(k == i ? ORANGE : 0xFF8E8E93);
        }
        update();
    }

    private String offsetText(String id) {
        TimeZone tz = TimeZone.getTimeZone(id);
        long now = System.currentTimeMillis();
        int diff = (tz.getOffset(now) - TimeZone.getDefault().getOffset(now)) / 3600000;
        if (diff == 0) {
            return "Bugün, +0 sa";
        }
        return "Bugün, " + (diff > 0 ? "+" : "") + diff + " sa";
    }

    private static String fmt(long ms, boolean centi) {
        long total = ms / 10;
        long cs = total % 100;
        long s = (total / 100) % 60;
        long m = total / 6000;
        return String.format(Locale.US, "%02d:%02d,%02d", m, s, cs);
    }

    // ------------------------------------------------------------------ kronometre

    private long swElapsed() {
        return swAccum + (swRunning ? SystemClock.elapsedRealtime() - swBase : 0);
    }

    private void swRightTap() {
        if (swRunning) {
            swAccum = swElapsed();
            swRunning = false;
        } else {
            swBase = SystemClock.elapsedRealtime();
            swRunning = true;
        }
        update();
    }

    private void swLeftTap() {
        if (swRunning) {
            long t = swElapsed();
            lapCount++;
            TextView r = tv(getContext(), "Tur " + lapCount + "      " + fmt(t - lastLap, true), 17f,
                    Color.WHITE, false);
            r.setPadding(0, dp(8), 0, dp(8));
            lapList.addView(r, 0, new LinearLayout.LayoutParams(MATCH, WRAP));
            lastLap = t;
        } else {
            swAccum = 0;
            lastLap = 0;
            lapCount = 0;
            lapList.removeAllViews();
        }
        update();
    }

    // ------------------------------------------------------------------ guncelleme

    private void update() {
        if (tab == 0) {
            long now = System.currentTimeMillis();
            analog.invalidate();
            for (int i = 0; i < cities.length; i++) {
                SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.US);
                f.setTimeZone(TimeZone.getTimeZone(cities[i][1]));
                cityTimes[i].setText(f.format(new Date(now)));
            }
        } else if (tab == 1) {
            swText.setText(fmt(swElapsed(), true));
            tint(swRight, swRunning ? 0xFF4A1512 : 0xFF0E3B1A, swRunning ? 0xFFFF453A : 0xFF30D158,
                    swRunning ? "Durdur" : "Başlat");
            swLeft.setText(swRunning ? "Tur" : "Sıfırla");
        } else {
            long left;
            if (tmRunning) {
                left = tmEnd - SystemClock.elapsedRealtime();
                if (left <= 0) {
                    tmRunning = false;
                    left = 0;
                    try {
                        ((Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE)).vibrate(900);
                    } catch (Throwable ignored) {
                    }
                    Toast.makeText(getContext(), "Zamanlayıcı bitti", Toast.LENGTH_LONG).show();
                }
            } else {
                left = tmMinutes * 60000L;
            }
            long secs = (left + 999) / 1000;
            long hh = secs / 3600;
            long mm = (secs / 60) % 60;
            long ss = secs % 60;
            tmText.setText(hh > 0
                    ? String.format(Locale.US, "%d:%02d:%02d", hh, mm, ss)
                    : String.format(Locale.US, "%d:%02d", mm, ss));
            tmHint.setText(tmRunning ? "kalan süre" : "dakika (+ ve − ile ayarla)");
            tint(tmButton, tmRunning ? 0xFF4A1512 : 0xFF0E3B1A, tmRunning ? 0xFFFF453A : 0xFF30D158,
                    tmRunning ? "Durdur" : "Başlat");
        }
    }

    // ------------------------------------------------------------------ analog saat

    private static final class AnalogView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        AnalogView(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float r = Math.min(w, getHeight()) / 2f - 4f;
            float cx = w / 2f;
            float cy = getHeight() / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1C1C1E);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 60; i++) {
                boolean big = i % 5 == 0;
                p.setStrokeWidth(big ? r * 0.025f : r * 0.012f);
                p.setColor(big ? 0xFFFFFFFF : 0xFF6B6B70);
                c.save();
                c.rotate(i * 6f, cx, cy);
                c.drawLine(cx, cy - r * 0.94f, cx, cy - r * (big ? 0.84f : 0.89f), p);
                c.restore();
            }
            Calendar cal = Calendar.getInstance();
            float ms = cal.get(Calendar.MILLISECOND) / 1000f;
            float sec = cal.get(Calendar.SECOND) + ms;
            float min = cal.get(Calendar.MINUTE) + sec / 60f;
            float hr = (cal.get(Calendar.HOUR) % 12) + min / 60f;
            hand(c, cx, cy, hr * 30f, r * 0.5f, r * 0.045f, 0xFFFFFFFF);
            hand(c, cx, cy, min * 6f, r * 0.76f, r * 0.03f, 0xFFFFFFFF);
            hand(c, cx, cy, sec * 6f, r * 0.84f, r * 0.014f, 0xFFFF9F0A);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF9F0A);
            c.drawCircle(cx, cy, r * 0.045f, p);
        }

        private void hand(Canvas c, float cx, float cy, float deg, float len, float wd, int col) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(wd);
            p.setColor(col);
            c.save();
            c.rotate(deg, cx, cy);
            c.drawLine(cx, cy + len * 0.14f, cx, cy - len, p);
            c.restore();
        }
    }
}
