package com.ilauncher.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;

/** Launcher'in kendi uygulamalari (Ayarlar, Hesap Makinesi, Notlar) icin koddan cizilen ikonlar. */
final class OwnIcons {
    private OwnIcons() {
    }

    static Bitmap make(Context ctx, int id, int px) {
        int n = px * 2;
        Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (id == 1) {
            settings(c, p, n);
        } else if (id == 2) {
            calculator(c, p, n);
        } else if (id == 4) {
            weather(c, p, n);
        } else if (id == 5) {
            clock(c, p, n);
        } else if (id == 6) {
            calendar(c, p, n);
        } else {
            notes(c, p, n);
        }
        return IconFactory.squircle(new BitmapDrawable(ctx.getResources(), b), px);
    }

    private static void settings(Canvas c, Paint p, int n) {
        p.setShader(new LinearGradient(0, 0, 0, n, 0xFFC9CBD2, 0xFF70727A, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, n, n, p);
        p.setShader(null);
        float cx = n / 2f;
        float cy = n / 2f;
        p.setColor(0xFFF2F2F7);
        RectF tooth = new RectF(cx - n * 0.065f, cy - n * 0.41f, cx + n * 0.065f, cy - n * 0.25f);
        for (int i = 0; i < 8; i++) {
            c.save();
            c.rotate(i * 45f, cx, cy);
            c.drawRoundRect(tooth, n * 0.025f, n * 0.025f, p);
            c.restore();
        }
        c.drawCircle(cx, cy, n * 0.30f, p);
        p.setColor(0xFF8D8F97);
        c.drawCircle(cx, cy, n * 0.13f, p);
    }

    private static void calculator(Canvas c, Paint p, int n) {
        p.setColor(0xFF1C1C1E);
        c.drawRect(0, 0, n, n, p);
        float cell = n * 0.28f;
        float gap = n * 0.07f;
        float start = (n - (2 * cell + gap)) / 2f;
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                boolean orange = i == 1 && j == 1;
                p.setColor(orange ? 0xFFFF9F0A : 0xFF636366);
                float l = start + j * (cell + gap);
                float t = start + i * (cell + gap);
                c.drawRoundRect(new RectF(l, t, l + cell, t + cell), n * 0.07f, n * 0.07f, p);
            }
        }
        p.setColor(0xFFFFFFFF);
        float l = start + cell + gap;
        float t = start + cell + gap;
        float w = cell * 0.5f;
        float x0 = l + (cell - w) / 2f;
        c.drawRoundRect(new RectF(x0, t + cell * 0.32f, x0 + w, t + cell * 0.32f + n * 0.03f), n * 0.015f, n * 0.015f, p);
        c.drawRoundRect(new RectF(x0, t + cell * 0.60f, x0 + w, t + cell * 0.60f + n * 0.03f), n * 0.015f, n * 0.015f, p);
    }

    private static void notes(Canvas c, Paint p, int n) {
        p.setColor(0xFFFFFFFF);
        c.drawRect(0, 0, n, n, p);
        p.setColor(0xFFFFCC00);
        c.drawRect(0, 0, n, n * 0.28f, p);
        p.setColor(0xFFD1D1D6);
        for (int i = 0; i < 3; i++) {
            float y = n * (0.46f + i * 0.16f);
            c.drawRoundRect(new RectF(n * 0.18f, y, n * 0.82f, y + n * 0.035f), n * 0.018f, n * 0.018f, p);
        }
    }

    private static void weather(Canvas c, Paint p, int n) {
        p.setShader(new LinearGradient(0, 0, 0, n, 0xFF2F7BFF, 0xFF7EC3FF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, n, n, p);
        p.setShader(null);
        float sx = n * 0.40f;
        float sy = n * 0.38f;
        p.setColor(0xFFFFD60A);
        c.drawCircle(sx, sy, n * 0.17f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(n * 0.035f);
        for (int i = 0; i < 8; i++) {
            c.save();
            c.rotate(i * 45f, sx, sy);
            c.drawLine(sx, sy - n * 0.23f, sx, sy - n * 0.29f, p);
            c.restore();
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        float cx = n * 0.55f;
        float cy = n * 0.64f;
        c.drawCircle(cx - n * 0.17f, cy + n * 0.02f, n * 0.14f, p);
        c.drawCircle(cx + n * 0.01f, cy - n * 0.08f, n * 0.19f, p);
        c.drawCircle(cx + n * 0.2f, cy + n * 0.03f, n * 0.13f, p);
        c.drawRoundRect(new RectF(cx - n * 0.3f, cy + n * 0.02f, cx + n * 0.33f, cy + n * 0.16f), n * 0.07f, n * 0.07f, p);
    }

    private static void clock(Canvas c, Paint p, int n) {
        p.setColor(0xFF000000);
        c.drawRect(0, 0, n, n, p);
        float cx = n / 2f;
        float cy = n / 2f;
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, n * 0.42f, p);
        p.setColor(0xFF1C1C1E);
        for (int i = 0; i < 12; i++) {
            c.save();
            c.rotate(i * 30f, cx, cy);
            c.drawRoundRect(new RectF(cx - n * 0.012f, cy - n * 0.38f, cx + n * 0.012f, cy - n * 0.33f), n * 0.01f, n * 0.01f, p);
            c.restore();
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF1C1C1E);
        p.setStrokeWidth(n * 0.03f);
        c.drawLine(cx, cy, cx - n * 0.1f, cy - n * 0.12f, p);
        p.setStrokeWidth(n * 0.022f);
        c.drawLine(cx, cy, cx + n * 0.02f, cy - n * 0.27f, p);
        p.setColor(0xFFFF9F0A);
        p.setStrokeWidth(n * 0.012f);
        c.drawLine(cx, cy + n * 0.05f, cx + n * 0.2f, cy + n * 0.14f, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, n * 0.02f, p);
    }

    private static void calendar(Canvas c, Paint p, int n) {
        p.setColor(0xFFFFFFFF);
        c.drawRect(0, 0, n, n, p);
        java.util.Calendar cal = java.util.Calendar.getInstance();
        String[] dn = {"PAZAR", "PAZARTESİ", "SALI", "ÇARŞAMBA", "PERŞEMBE", "CUMA", "CUMARTESİ"};
        p.setColor(0xFFFF3B30);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(n * 0.115f);
        c.drawText(dn[cal.get(java.util.Calendar.DAY_OF_WEEK) - 1], n / 2f, n * 0.25f, p);
        p.setColor(0xFF000000);
        p.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        p.setTextSize(n * 0.56f);
        c.drawText(String.valueOf(cal.get(java.util.Calendar.DAY_OF_MONTH)), n / 2f, n * 0.80f, p);
    }
}
