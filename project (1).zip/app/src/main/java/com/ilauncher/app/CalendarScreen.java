package com.ilauncher.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

/** iPhone tarzi takvim (ay gorunumu). */
final class CalendarScreen extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int RED = 0xFFFF3B30;
    private static final String[] MONTHS = {"Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
            "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"};
    private static final String[] DAYS = {"Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"};
    private static final String[] LONG_DAYS = {"Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma",
            "Cumartesi"};

    private final LinearLayout grid;
    private final TextView title;
    private final TextView yearTv;
    private final TextView selected;
    private int year;
    private int month;
    private int selDay;
    private final int todayY;
    private final int todayM;
    private final int todayD;

    CalendarScreen(Context c, Host h) {
        super(c, h);
        setBackgroundColor(Color.WHITE);
        Calendar now = Calendar.getInstance();
        todayY = now.get(Calendar.YEAR);
        todayM = now.get(Calendar.MONTH);
        todayD = now.get(Calendar.DAY_OF_MONTH);
        year = todayY;
        month = todayM;
        selDay = todayD;

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(52), dp(12), dp(34) + host.bottomInset());
        addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), 0, dp(8), 0);
        yearTv = tv(c, "", 20f, RED, true);
        head.addView(yearTv, new LinearLayout.LayoutParams(WRAP, WRAP));
        View sp = new View(c);
        head.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView prev = tv(c, "‹", 34f, RED, false);
        TextView next = tv(c, "›", 34f, RED, false);
        prev.setPadding(dp(16), 0, dp(16), 0);
        next.setPadding(dp(16), 0, dp(8), 0);
        head.addView(prev, new LinearLayout.LayoutParams(WRAP, WRAP));
        head.addView(next, new LinearLayout.LayoutParams(WRAP, WRAP));
        col.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        title = tv(c, "", 34f, Color.BLACK, true);
        title.setPadding(dp(8), 0, 0, dp(10));
        col.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout wk = new LinearLayout(c);
        wk.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            TextView t = tv(c, DAYS[i], 12f, i >= 5 ? 0xFF8E8E93 : 0xFF3C3C43, true);
            t.setGravity(Gravity.CENTER);
            wk.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        col.addView(wk, new LinearLayout.LayoutParams(MATCH, WRAP));
        View line = new View(c);
        line.setBackgroundColor(0xFFD1D1D6);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MATCH, 1);
        ll.topMargin = dp(6);
        col.addView(line, ll);

        grid = new LinearLayout(c);
        grid.setOrientation(LinearLayout.VERTICAL);
        col.addView(grid, new LinearLayout.LayoutParams(MATCH, WRAP));

        selected = tv(c, "", 17f, Color.BLACK, true);
        selected.setPadding(dp(8), dp(22), dp(8), dp(6));
        col.addView(selected, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView none = tv(c, "Bu gün için etkinlik yok", 15f, 0xFF8E8E93, false);
        none.setPadding(dp(8), 0, dp(8), 0);
        col.addView(none, new LinearLayout.LayoutParams(MATCH, WRAP));

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shift(-1);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shift(1);
            }
        });
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                year = todayY;
                month = todayM;
                selDay = todayD;
                build();
            }
        });
        build();
        addHomeBar(false);
    }

    @Override
    boolean darkStatus() {
        return true;
    }

    private TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private void shift(int delta) {
        month += delta;
        if (month < 0) {
            month = 11;
            year--;
        } else if (month > 11) {
            month = 0;
            year++;
        }
        selDay = 1;
        if (year == todayY && month == todayM) {
            selDay = todayD;
        }
        build();
    }

    private void build() {
        Context c = getContext();
        yearTv.setText(String.valueOf(year));
        title.setText(MONTHS[month]);
        grid.removeAllViews();
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        int offset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int d = 1 - offset;
        for (int r = 0; r < 6; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 7; k++, d++) {
                FrameLayout cell = new FrameLayout(c);
                if (d >= 1 && d <= days) {
                    final int day = d;
                    boolean today = year == todayY && month == todayM && d == todayD;
                    boolean sel = d == selDay;
                    TextView t = tv(c, String.valueOf(d), 19f,
                            today ? Color.WHITE : (k >= 5 ? 0xFF8E8E93 : Color.BLACK), today || sel);
                    t.setGravity(Gravity.CENTER);
                    if (today || sel) {
                        GradientDrawable g = new GradientDrawable();
                        g.setShape(GradientDrawable.OVAL);
                        g.setColor(today ? RED : 0xFFE5E5EA);
                        t.setBackground(g);
                    }
                    FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER);
                    cell.addView(t, tl);
                    cell.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            selDay = day;
                            build();
                        }
                    });
                }
                row.addView(cell, new LinearLayout.LayoutParams(0, dp(52), 1f));
            }
            grid.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        Calendar s = Calendar.getInstance();
        s.set(year, month, selDay);
        selected.setText(selDay + " " + MONTHS[month] + " " + year + ", "
                + LONG_DAYS[s.get(Calendar.DAY_OF_WEEK) - 1]);
    }
}
