package com.ilauncher.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Dynamic Island benzeri siyah hap. Dokununca ya da sarj takilinca genisleyip pil bilgisini gosterir. */
final class IslandView extends View {
    private static final float TOP_DP = 10f;

    private final float d;
    private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bolt = new Path();
    private final RectF rect = new RectF();
    private final Runnable collapse = new Runnable() {
        @Override
        public void run() {
            animateTo(0f);
        }
    };
    private float expand;
    private boolean initialized;
    private boolean lastCharging;
    private boolean charging;
    private ValueAnimator anim;
    private String info = "";

    IslandView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        pill.setColor(Color.BLACK);
        text.setColor(Color.WHITE);
        text.setTextSize(14f * d);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        boltPaint.setStyle(Paint.Style.FILL);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expand < 0.5f) {
                    pulse();
                } else {
                    removeCallbacks(collapse);
                    animateTo(0f);
                }
            }
        });
    }

    /** Adayi acar, birkac saniye sonra kendiliginden kapatir. */
    void pulse() {
        removeCallbacks(collapse);
        animateTo(1f);
        postDelayed(collapse, 2800);
    }

    void setBattery(int pct, boolean isCharging) {
        boolean changed = initialized && isCharging != lastCharging;
        initialized = true;
        lastCharging = isCharging;
        charging = isCharging;
        info = (isCharging ? "Şarj oluyor  %" : "Pil  %") + pct;
        invalidate();
        // Sarj takilinca ya da cekilince ada kendiliginden acilir (iPhone gibi).
        if (changed) {
            pulse();
        }
    }

    private void animateTo(float target) {
        if (anim != null) {
            anim.cancel();
        }
        anim = ValueAnimator.ofFloat(expand, target);
        anim.setDuration(target > expand ? 520 : 340);
        anim.setInterpolator(target > expand ? Fx.SPRING : Fx.SMOOTH);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                expand = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    private RectF pillRect() {
        float e = Math.max(0f, expand);
        float w = (104f + (214f - 104f) * e) * d;
        float h = (30f + (46f - 30f) * Math.min(1.1f, e)) * d;
        float cx = getWidth() / 2f;
        float top = TOP_DP * d;
        rect.set(cx - w / 2f, top, cx + w / 2f, top + h);
        return rect;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN && !pillRect().contains(e.getX(), e.getY())) {
            return false;
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        RectF r = pillRect();
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, pill);
        if (expand > 0.55f) {
            int a = Math.round(255 * Math.min(1f, (expand - 0.55f) / 0.45f));
            text.setAlpha(a);
            float shift = charging ? 8f * d : 0f;
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(info, r.centerX() + shift, r.centerY() - (fm.ascent + fm.descent) / 2f, text);
            if (charging) {
                float bx = r.left + 22f * d;
                float cy = r.centerY();
                bolt.reset();
                bolt.moveTo(bx + 2.2f * d, cy - 9f * d);
                bolt.lineTo(bx - 4f * d, cy + 1.2f * d);
                bolt.lineTo(bx - 0.4f * d, cy + 1.2f * d);
                bolt.lineTo(bx - 2.2f * d, cy + 9f * d);
                bolt.lineTo(bx + 4f * d, cy - 1.5f * d);
                bolt.lineTo(bx + 0.4f * d, cy - 1.5f * d);
                bolt.close();
                boltPaint.setColor(0xFF30D158);
                boltPaint.setAlpha(a);
                c.drawPath(bolt, boltPaint);
            }
        }
    }
}
