package com.ilauncher.app;

import android.animation.TimeInterpolator;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;

/** Ortak animasyon ve efekt yardimcilari. */
final class Fx {
    private Fx() {
    }

    /** iOS'a benzer yumusak yay (spring): hafif asar ve yerine oturur. */
    static final TimeInterpolator SPRING = new TimeInterpolator() {
        @Override
        public float getInterpolation(float t) {
            if (t >= 1f) {
                return 1f;
            }
            return (float) (1.0 - Math.exp(-7.5 * t) * Math.cos(10.5 * t));
        }
    };

    /** Cok hafif yay (asma payi kucuk). */
    static final TimeInterpolator SPRING_MILD = new TimeInterpolator() {
        @Override
        public float getInterpolation(float t) {
            if (t >= 1f) {
                return 1f;
            }
            return (float) (1.0 - Math.exp(-9.5 * t) * Math.cos(9.5 * t));
        }
    };

    /** Hizli baslayip yumusak biten egri (uygulama acilis/kapanis). */
    static final TimeInterpolator SMOOTH = new PathInterpolator(0.22f, 1f, 0.36f, 1f);

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Gorunumu bulaniklastirir (Android 12 ve ustunde gercek bulaniklik; altinda etkisiz). */
    static void blur(View v, float radius) {
        if (Build.VERSION.SDK_INT >= 31) {
            if (radius < 0.5f) {
                v.setRenderEffect(null);
            } else {
                v.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP));
            }
        }
    }
}
