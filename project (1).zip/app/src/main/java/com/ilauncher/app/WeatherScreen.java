package com.ilauncher.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** iPhone tarzi hava durumu (Open-Meteo, anahtar gerektirmez). */
final class WeatherScreen extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final SharedPreferences sp;
    private final GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xFF3A8DFF, 0xFF8CC8FF});
    private final TextView cityTv;
    private final TextView tempTv;
    private final TextView condTv;
    private final TextView hlTv;
    private final TextView statusTv;
    private final WIcon bigIcon;
    private final LinearLayout hourlyRow;
    private final LinearLayout dailyCol;
    private final LinearLayout detailRow;
    private String city;
    private double lat;
    private double lon;
    private boolean dead;

    WeatherScreen(Context c, Host h) {
        super(c, h);
        sp = c.getSharedPreferences("ilauncher_weather", Context.MODE_PRIVATE);
        city = sp.getString("city", "İstanbul");
        lat = Double.parseDouble(sp.getString("lat", "41.0138"));
        lon = Double.parseDouble(sp.getString("lon", "28.9497"));
        setBackground(bg);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(52), dp(16), dp(60) + host.bottomInset());
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));

        TextView change = text(c, "Şehir değiştir", 13f, 0xFFFFFFFF, true);
        change.setPadding(dp(14), dp(7), dp(14), dp(7));
        change.setBackground(round(0x33FFFFFF, 18));
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askCity();
            }
        });
        LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        chLp.gravity = Gravity.END;
        col.addView(change, chLp);

        cityTv = text(c, city, 32f, 0xFFFFFFFF, false);
        cityTv.setGravity(Gravity.CENTER);
        col.addView(cityTv, new LinearLayout.LayoutParams(MATCH, WRAP));

        bigIcon = new WIcon(c);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(96), dp(96));
        ilp.gravity = Gravity.CENTER_HORIZONTAL;
        ilp.topMargin = dp(8);
        col.addView(bigIcon, ilp);

        tempTv = text(c, "--°", 88f, 0xFFFFFFFF, false);
        tempTv.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        tempTv.setGravity(Gravity.CENTER);
        tempTv.setIncludeFontPadding(false);
        col.addView(tempTv, new LinearLayout.LayoutParams(MATCH, WRAP));

        condTv = text(c, "", 20f, 0xEEFFFFFF, true);
        condTv.setGravity(Gravity.CENTER);
        col.addView(condTv, new LinearLayout.LayoutParams(MATCH, WRAP));

        hlTv = text(c, "", 16f, 0xCCFFFFFF, false);
        hlTv.setGravity(Gravity.CENTER);
        col.addView(hlTv, new LinearLayout.LayoutParams(MATCH, WRAP));

        statusTv = text(c, "Yükleniyor…", 12f, 0xAAFFFFFF, false);
        statusTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        stLp.topMargin = dp(4);
        col.addView(statusTv, stLp);

        // Saatlik
        LinearLayout hourCard = card(c);
        hourCard.addView(text(c, "SAATLİK TAHMİN", 12f, 0xB3FFFFFF, true));
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        hourlyRow = new LinearLayout(c);
        hourlyRow.setOrientation(LinearLayout.HORIZONTAL);
        hourlyRow.setPadding(0, dp(10), 0, 0);
        hs.addView(hourlyRow, new ViewGroup.LayoutParams(WRAP, WRAP));
        hourCard.addView(hs, new LinearLayout.LayoutParams(MATCH, WRAP));
        addCard(col, hourCard);

        // 7 gunluk
        LinearLayout dayCard = card(c);
        dayCard.addView(text(c, "7 GÜNLÜK TAHMİN", 12f, 0xB3FFFFFF, true));
        dailyCol = new LinearLayout(c);
        dailyCol.setOrientation(LinearLayout.VERTICAL);
        dayCard.addView(dailyCol, new LinearLayout.LayoutParams(MATCH, WRAP));
        addCard(col, dayCard);

        // Ayrintilar
        detailRow = new LinearLayout(c);
        detailRow.setOrientation(LinearLayout.HORIZONTAL);
        addCard(col, detailRow);

        addView(sv, new FrameLayout.LayoutParams(MATCH, MATCH));
        addHomeBar(true);
        load();
    }

    @Override
    boolean darkStatus() {
        return false;
    }

    @Override
    void onClosing() {
        dead = true;
    }

    // ------------------------------------------------------------------ yardimcilar

    private TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        return l;
    }

    private void addCard(LinearLayout parent, LinearLayout card) {
        card.setBackground(round(0x33FFFFFF, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(14);
        parent.addView(card, lp);
    }

    private static String get(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(9000);
        con.setReadTimeout(9000);
        InputStream in = con.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
        }
        in.close();
        return bo.toString("UTF-8");
    }

    // ------------------------------------------------------------------ sehir arama

    private void askCity() {
        final EditText et = new EditText(getContext());
        et.setHint("Şehir adı (ör. Ankara)");
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setSingleLine(true);
        new AlertDialog.Builder(getContext())
                .setTitle("Şehir ara")
                .setView(et)
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Ara", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        final String q = et.getText().toString().trim();
                        if (!q.isEmpty()) {
                            search(q);
                        }
                    }
                }).show();
    }

    private void search(final String q) {
        statusTv.setText("Aranıyor…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String r = get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=tr&name="
                            + URLEncoder.encode(q, "UTF-8"));
                    JSONObject o = new JSONObject(r);
                    JSONArray a = o.optJSONArray("results");
                    if (a == null || a.length() == 0) {
                        post(new Runnable() {
                            @Override
                            public void run() {
                                statusTv.setText("");
                                Toast.makeText(getContext(), "Şehir bulunamadı", Toast.LENGTH_SHORT).show();
                            }
                        });
                        return;
                    }
                    JSONObject f = a.getJSONObject(0);
                    city = f.getString("name");
                    lat = f.getDouble("latitude");
                    lon = f.getDouble("longitude");
                    sp.edit().putString("city", city).putString("lat", String.valueOf(lat))
                            .putString("lon", String.valueOf(lon)).apply();
                    post(new Runnable() {
                        @Override
                        public void run() {
                            cityTv.setText(city);
                            load();
                        }
                    });
                } catch (Throwable t) {
                    post(new Runnable() {
                        @Override
                        public void run() {
                            statusTv.setText("İnternet bağlantısı yok");
                        }
                    });
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------ veri

    private void load() {
        statusTv.setText("Yükleniyor…");
        final String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day"
                + "&hourly=temperature_2m,weather_code"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                + "&timezone=auto&forecast_days=7&wind_speed_unit=kmh";
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final JSONObject o = new JSONObject(get(url));
                    post(new Runnable() {
                        @Override
                        public void run() {
                            if (!dead) {
                                apply(o);
                            }
                        }
                    });
                } catch (Throwable t) {
                    post(new Runnable() {
                        @Override
                        public void run() {
                            statusTv.setText("İnternet bağlantısı yok. İnternete bağlanıp tekrar aç.");
                        }
                    });
                }
            }
        }).start();
    }

    private void apply(JSONObject o) {
        try {
            Context c = getContext();
            JSONObject cur = o.getJSONObject("current");
            int code = cur.getInt("weather_code");
            boolean night = cur.optInt("is_day", 1) == 0;
            tempTv.setText(Math.round(cur.getDouble("temperature_2m")) + "°");
            condTv.setText(describe(code));
            bigIcon.set(kind(code), night);
            setSky(code, night);

            JSONObject daily = o.getJSONObject("daily");
            JSONArray dt = daily.getJSONArray("time");
            JSONArray dc = daily.getJSONArray("weather_code");
            JSONArray dmax = daily.getJSONArray("temperature_2m_max");
            JSONArray dmin = daily.getJSONArray("temperature_2m_min");
            hlTv.setText("Y:" + Math.round(dmax.getDouble(0)) + "°   D:" + Math.round(dmin.getDouble(0)) + "°");

            // saatlik
            hourlyRow.removeAllViews();
            JSONObject hr = o.getJSONObject("hourly");
            JSONArray ht = hr.getJSONArray("time");
            JSONArray htemp = hr.getJSONArray("temperature_2m");
            JSONArray hcode = hr.getJSONArray("weather_code");
            String now = cur.getString("time").substring(0, 13);
            int start = 0;
            for (int i = 0; i < ht.length(); i++) {
                if (ht.getString(i).substring(0, 13).compareTo(now) >= 0) {
                    start = i;
                    break;
                }
            }
            for (int i = start; i < Math.min(ht.length(), start + 24); i++) {
                int hour = Integer.parseInt(ht.getString(i).substring(11, 13));
                LinearLayout cell = new LinearLayout(c);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                TextView tt = text(c, i == start ? "Şimdi" : String.format(Locale.US, "%02d", hour), 14f,
                        0xFFFFFFFF, true);
                tt.setGravity(Gravity.CENTER);
                cell.addView(tt, new LinearLayout.LayoutParams(WRAP, WRAP));
                WIcon wi = new WIcon(c);
                wi.set(kind(hcode.getInt(i)), hour < 6 || hour >= 20);
                LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(dp(30), dp(30));
                wl.topMargin = dp(8);
                wl.bottomMargin = dp(8);
                cell.addView(wi, wl);
                cell.addView(text(c, Math.round(htemp.getDouble(i)) + "°", 17f, 0xFFFFFFFF, true),
                        new LinearLayout.LayoutParams(WRAP, WRAP));
                hourlyRow.addView(cell, new LinearLayout.LayoutParams(dp(54), WRAP));
            }

            // gunluk
            dailyCol.removeAllViews();
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            SimpleDateFormat out = new SimpleDateFormat("EEEE", new Locale("tr"));
            for (int i = 0; i < dt.length(); i++) {
                LinearLayout row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                String name = "";
                try {
                    Date dd = in.parse(dt.getString(i));
                    name = i == 0 ? "Bugün" : out.format(dd);
                } catch (Throwable ignored) {
                }
                row.addView(text(c, name, 17f, 0xFFFFFFFF, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
                WIcon wi = new WIcon(c);
                wi.set(kind(dc.getInt(i)), false);
                row.addView(wi, new LinearLayout.LayoutParams(dp(30), dp(30)));
                TextView lo = text(c, Math.round(dmin.getDouble(i)) + "°", 17f, 0x99FFFFFF, false);
                lo.setGravity(Gravity.END);
                row.addView(lo, new LinearLayout.LayoutParams(dp(48), WRAP));
                TextView hi = text(c, Math.round(dmax.getDouble(i)) + "°", 17f, 0xFFFFFFFF, true);
                hi.setGravity(Gravity.END);
                row.addView(hi, new LinearLayout.LayoutParams(dp(44), WRAP));
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(MATCH, WRAP);
                rl.topMargin = dp(i == 0 ? 6 : 12);
                dailyCol.addView(row, rl);
            }

            // ayrintilar
            detailRow.removeAllViews();
            detail(c, "HİSSEDİLEN", Math.round(cur.getDouble("apparent_temperature")) + "°");
            detail(c, "NEM", "%" + Math.round(cur.getDouble("relative_humidity_2m")));
            detail(c, "RÜZGAR", Math.round(cur.getDouble("wind_speed_10m")) + " km/s");

            statusTv.setText("Güncellendi " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()));
        } catch (Throwable t) {
            statusTv.setText("Veri okunamadı");
        }
    }

    private void detail(Context c, String title, String value) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(0, dp(14), 0, dp(14));
        TextView a = text(c, title, 11f, 0xB3FFFFFF, true);
        a.setGravity(Gravity.CENTER);
        l.addView(a, new LinearLayout.LayoutParams(WRAP, WRAP));
        TextView b = text(c, value, 22f, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(WRAP, WRAP);
        bl.topMargin = dp(6);
        l.addView(b, bl);
        detailRow.addView(l, new LinearLayout.LayoutParams(0, WRAP, 1f));
    }

    private void setSky(int code, boolean night) {
        int a;
        int b;
        int k = kind(code);
        if (night) {
            a = 0xFF0B1A3A;
            b = 0xFF2A3F6B;
        } else if (k == 6) {
            a = 0xFF2B2F45;
            b = 0xFF595F7A;
        } else if (k == 4) {
            a = 0xFF3B4A63;
            b = 0xFF6C7B93;
        } else if (k == 5) {
            a = 0xFF7B8CA8;
            b = 0xFFC4D0E0;
        } else if (k == 3) {
            a = 0xFF8A94A0;
            b = 0xFFB8C0C8;
        } else if (k == 2) {
            a = 0xFF5C6B80;
            b = 0xFF9AA8B8;
        } else {
            a = 0xFF3A8DFF;
            b = 0xFF8CC8FF;
        }
        bg.setColors(new int[]{a, b});
        invalidate();
    }

    // 0 gunes, 1 parcali bulutlu, 2 bulutlu, 3 sis, 4 yagmur, 5 kar, 6 firtina
    private static int kind(int code) {
        if (code == 0) {
            return 0;
        }
        if (code == 1 || code == 2) {
            return 1;
        }
        if (code == 3) {
            return 2;
        }
        if (code == 45 || code == 48) {
            return 3;
        }
        if (code >= 51 && code <= 67 || code >= 80 && code <= 82) {
            return 4;
        }
        if (code >= 71 && code <= 77 || code == 85 || code == 86) {
            return 5;
        }
        if (code >= 95) {
            return 6;
        }
        return 2;
    }

    private static String describe(int code) {
        switch (kind(code)) {
            case 0:
                return "Açık";
            case 1:
                return "Parçalı bulutlu";
            case 2:
                return "Bulutlu";
            case 3:
                return "Sisli";
            case 4:
                return code >= 80 ? "Sağanak yağmur" : "Yağmurlu";
            case 5:
                return "Karlı";
            default:
                return "Gök gürültülü fırtına";
        }
    }

    // ------------------------------------------------------------------ hava ikonu

    static final class WIcon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int kind;
        private boolean night;

        WIcon(Context c) {
            super(c);
        }

        void set(int k, boolean n) {
            kind = k;
            night = n;
            invalidate();
        }

        private void sun(Canvas c, float cx, float cy, float r) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFD60A);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(r * 0.22f);
            for (int i = 0; i < 8; i++) {
                c.save();
                c.rotate(i * 45f, cx, cy);
                c.drawLine(cx, cy - r * 1.35f, cx, cy - r * 1.7f, p);
                c.restore();
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void moon(Canvas c, float cx, float cy, float r) {
            Path a = new Path();
            a.addCircle(cx, cy, r, Path.Direction.CW);
            Path b = new Path();
            b.addCircle(cx + r * 0.55f, cy - r * 0.35f, r * 0.85f, Path.Direction.CW);
            a.op(b, Path.Op.DIFFERENCE);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFF5F5DC);
            c.drawPath(a, p);
        }

        private void cloud(Canvas c, float cx, float cy, float s, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(cx - s * 0.18f, cy + s * 0.02f, s * 0.2f, p);
            c.drawCircle(cx + s * 0.02f, cy - s * 0.1f, s * 0.26f, p);
            c.drawCircle(cx + s * 0.24f, cy + s * 0.04f, s * 0.18f, p);
            c.drawRoundRect(new RectF(cx - s * 0.38f, cy + s * 0.02f, cx + s * 0.42f, cy + s * 0.22f),
                    s * 0.1f, s * 0.1f, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float s = Math.min(w, h);
            float cx = w / 2f;
            float cy = h / 2f;
            switch (kind) {
                case 0:
                    if (night) {
                        moon(c, cx, cy, s * 0.3f);
                    } else {
                        sun(c, cx, cy, s * 0.24f);
                    }
                    break;
                case 1:
                    if (night) {
                        moon(c, cx - s * 0.1f, cy - s * 0.12f, s * 0.2f);
                    } else {
                        sun(c, cx - s * 0.12f, cy - s * 0.14f, s * 0.16f);
                    }
                    cloud(c, cx + s * 0.04f, cy + s * 0.14f, s * 0.95f, 0xFFFFFFFF);
                    break;
                case 2:
                    cloud(c, cx, cy, s, 0xFFEFEFF4);
                    break;
                case 3:
                    cloud(c, cx, cy - s * 0.1f, s * 0.9f, 0xCCFFFFFF);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(s * 0.06f);
                    p.setColor(0xCCFFFFFF);
                    c.drawLine(cx - s * 0.3f, cy + s * 0.22f, cx + s * 0.3f, cy + s * 0.22f, p);
                    c.drawLine(cx - s * 0.2f, cy + s * 0.34f, cx + s * 0.4f, cy + s * 0.34f, p);
                    break;
                case 4:
                    cloud(c, cx, cy - s * 0.12f, s * 0.95f, 0xFFD8DCE4);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(s * 0.06f);
                    p.setColor(0xFF64B5FF);
                    for (int i = -1; i <= 1; i++) {
                        c.drawLine(cx + i * s * 0.2f + s * 0.04f, cy + s * 0.2f,
                                cx + i * s * 0.2f - s * 0.04f, cy + s * 0.36f, p);
                    }
                    break;
                case 5:
                    cloud(c, cx, cy - s * 0.12f, s * 0.95f, 0xFFE4E8EE);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFFFFFFF);
                    for (int i = -1; i <= 1; i++) {
                        c.drawCircle(cx + i * s * 0.2f, cy + s * 0.3f + (i == 0 ? s * 0.04f : 0), s * 0.05f, p);
                    }
                    break;
                default:
                    cloud(c, cx, cy - s * 0.12f, s * 0.95f, 0xFF8E94A8);
                    Path b = new Path();
                    b.moveTo(cx + s * 0.06f, cy + s * 0.12f);
                    b.lineTo(cx - s * 0.1f, cy + s * 0.3f);
                    b.lineTo(cx, cy + s * 0.3f);
                    b.lineTo(cx - s * 0.06f, cy + s * 0.44f);
                    b.lineTo(cx + s * 0.14f, cy + s * 0.24f);
                    b.lineTo(cx + s * 0.04f, cy + s * 0.24f);
                    b.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFFFD60A);
                    c.drawPath(b, p);
                    break;
            }
        }
    }
}
