package com.ilauncher.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Koddan cizilen, iPhone tarzi renkli gecis duvar kagidi. Sarj olurken altta yesil bir isik nefes alir. */
final class WallpaperView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean charging;
    private float chargeAlpha;
    private float phase;
    private ValueAnimator fade;
    private ValueAnimator pulse;

    WallpaperView(Context context) {
        super(context);
    }

    void setCharging(boolean on) {
        if (on == charging) {
            return;
        }
        charging = on;
        if (fade != null) {
            fade.cancel();
        }
        fade = ValueAnimator.ofFloat(chargeAlpha, on ? 1f : 0f);
        fade.setDuration(900);
        fade.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                chargeAlpha = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        fade.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                if (!charging && pulse != null) {
                    pulse.cancel();
                }
            }
        });
        fade.start();
        if (on) {
            if (pulse == null) {
                pulse = ValueAnimator.ofFloat(0f, 1f);
                pulse.setDuration(2400);
                pulse.setRepeatCount(ValueAnimator.INFINITE);
                pulse.setRepeatMode(ValueAnimator.REVERSE);
                pulse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator a) {
                        phase = (Float) a.getAnimatedValue();
                        invalidate();
                    }
                });
            }
            if (!pulse.isStarted()) {
                pulse.start();
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        paint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF1B1464, 0xFF5B2A86, 0xFF1A1240},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);

        blob(canvas, w * 0.15f, h * 0.18f, w * 0.95f, 0xFFFF5F6D, 0.75f);
        blob(canvas, w * 0.90f, h * 0.50f, w * 1.00f, 0xFF00C6FF, 0.60f);
        blob(canvas, w * 0.25f, h * 0.95f, w * 1.00f, 0xFFFFB75E, 0.70f);

        if (chargeAlpha > 0.01f) {
            float a = (0.20f + 0.14f * phase) * chargeAlpha;
            blob(canvas, w * 0.5f, h * 1.04f, w * 1.15f, 0xFF30D158, a);
        }
    }

    private void blob(Canvas canvas, float x, float y, float radius, int color, float alpha) {
        int rgb = color & 0x00FFFFFF;
        int center = rgb | (Math.round(255 * alpha) << 24);
        paint.setShader(new RadialGradient(x, y, radius, center, rgb, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
    }
}
