package com.ilauncher.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/** Launcher icinde acilan tam ekran uygulamalarin ortak tabani (Ayarlar, Hesap Makinesi...). */
abstract class ScreenBase extends FrameLayout {

    interface Host {
        void closeScreen(ScreenBase s);

        void openInternal(int id, View from);

        boolean launchIntent(Intent i);

        int bottomInset();
    }

    protected final Host host;
    protected final float d;

    // ---- ikondan tam ekrana donusen (morph) acilis animasyonu
    private int mw;
    private int mh;
    private final RectF from = new RectF();
    private float fromR;
    private float morph = 1f;
    private float dragY;
    private float dragAlpha = 1f;
    private float outH;
    private float outR;

    ScreenBase(Context c, Host h) {
        super(c);
        host = h;
        d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
        setClipToOutline(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                int w = v.getWidth();
                int hh = outH > 0f ? Math.round(outH) : v.getHeight();
                o.setRoundRect(0, 0, w, Math.max(1, hh), outR);
            }
        });
    }

    protected int dp(float v) {
        return Math.round(v * d);
    }

    /** Durum cubugu yazilari koyu olsun mu (acik renkli ekranlar icin true). */
    abstract boolean darkStatus();

    /** Yari saydam katman mi (Kontrol Merkezi gibi); true ise ana ekran arkada kalir. */
    boolean translucent() {
        return false;
    }

    /** Geri tusu: ekran kendi icinde bir sey yaptiysa true dondurur. */
    boolean onBack() {
        return false;
    }

    /** Kapanmadan hemen once cagrilir (kaydetmek icin). */
    void onClosing() {
    }

    // ------------------------------------------------------------------ morph

    void setMorphGeometry(int w, int h, RectF iconRect, float iconRadiusPx) {
        mw = w;
        mh = h;
        from.set(iconRect);
        fromR = iconRadiusPx;
    }

    /** p = 0: ikon boyutunda, p = 1: tam ekran. */
    void setMorph(float p) {
        morph = p;
        if (mw == 0 || mh == 0) {
            return;
        }
        float q = Math.max(0f, Math.min(1f, p));
        float s = Fx.lerp(from.width() / mw, 1f, q);
        setPivotX(0f);
        setPivotY(0f);
        setScaleX(s);
        setScaleY(s);
        setTranslationX(Fx.lerp(from.left, 0f, q));
        setTranslationY(Fx.lerp(from.top, 0f, q) + dragY);
        outH = Fx.lerp(from.height(), mh, q) / s;
        outR = Fx.lerp(fromR, 0f, q) / s;
        invalidateOutline();
        setAlpha(Math.min(1f, q * 5f) * dragAlpha);
    }

    /** Yukari surukleme sirasinda ekrani kaydirir ve soldurur. */
    void setDrag(float dy, float alpha) {
        dragY = dy;
        dragAlpha = alpha;
        if (mw == 0) {
            setTranslationY(dy);
            setAlpha(alpha);
        } else {
            setMorph(morph);
        }
    }

    void animateMorph(float to, long duration, TimeInterpolator ip, final Runnable end) {
        final float start = morph;
        final float dy0 = dragY;
        final float da0 = dragAlpha;
        final float target = to;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(duration);
        a.setInterpolator(ip);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator u) {
                float t = (Float) u.getAnimatedValue();
                dragY = dy0 * (1f - t);
                dragAlpha = da0 + (1f - da0) * t;
                setMorph(start + (target - start) * t);
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (end != null) {
                    end.run();
                }
            }
        });
        a.start();
    }

    // ------------------------------------------------------------------ ana ekran cubugu

    /** Alta iPhone'daki gibi ana ekran cubugu ekler; yukari cekince ekran kapanir. */
    protected void addHomeBar(final boolean lightBar) {
        final int h = dp(34) + host.bottomInset();
        final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setColor(lightBar ? 0xCCFFFFFF : 0xCC000000);
        final RectF r = new RectF();

        View strip = new View(getContext()) {
            @Override
            protected void onDraw(Canvas c) {
                float w = dp(134);
                float bh = dp(5);
                float cx = getWidth() / 2f;
                float cy = getHeight() - host.bottomInset() - dp(10);
                r.set(cx - w / 2f, cy - bh / 2f, cx + w / 2f, cy + bh / 2f);
                c.drawRoundRect(r, bh / 2f, bh / 2f, barPaint);
            }
        };
        strip.setOnTouchListener(new View.OnTouchListener() {
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = Math.min(0f, e.getRawY() - downY);
                        float f = Math.min(1f, -dy / dp(420));
                        ScreenBase.this.setDrag(dy * 0.9f, 1f - 0.4f * f);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (downY - e.getRawY() > dp(100)) {
                            host.closeScreen(ScreenBase.this);
                        } else {
                            ScreenBase.this.animateMorph(1f, 260, Fx.SPRING_MILD, null);
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        addView(strip, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM));
    }
}
