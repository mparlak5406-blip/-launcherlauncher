package com.ilauncher.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** iPhone tarzi basit Notlar uygulamasi. Notlar telefonda yerel olarak saklanir. */
final class NotesScreen extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int BG = 0xFFF2F2F7;
    private static final int YELLOW = 0xFFE0A800;

    private static final class Note {
        String text;
        long ts;

        Note(String text, long ts) {
            this.text = text;
            this.ts = ts;
        }
    }

    private final SharedPreferences prefs;
    private final List<Note> notes = new ArrayList<>();
    private final FrameLayout listLayer;
    private final LinearLayout listBody;
    private final TextView countView;
    private final LinearLayout editorLayer;
    private final EditText edit;
    private int editing = -1;
    private int lastPad = 0;

    private final ViewTreeObserver.OnGlobalLayoutListener keyboardListener =
            new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    Rect r = new Rect();
                    getWindowVisibleDisplayFrame(r);
                    int overlap = getRootView().getHeight() - r.bottom;
                    int pad = overlap > host.bottomInset() + dp(100) ? overlap : 0;
                    if (pad != lastPad) {
                        lastPad = pad;
                        NotesScreen.this.editorLayer.setPadding(0, 0, 0, pad);
                    }
                }
            };

    NotesScreen(Context c, Host h) {
        super(c, h);
        setBackgroundColor(BG);
        prefs = c.getSharedPreferences("ilauncher_notes", Context.MODE_PRIVATE);
        load();

        // ---- liste
        listLayer = new FrameLayout(c);
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(56), dp(16), dp(34) + host.bottomInset() + dp(90));
        sv.addView(content, new FrameLayout.LayoutParams(MATCH, WRAP));

        TextView title = label(c, "Notlar", 34f, 0xFF000000, true);
        title.setPadding(dp(4), 0, 0, 0);
        content.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));
        countView = label(c, "", 14f, 0xFF8E8E93, false);
        countView.setPadding(dp(4), 0, 0, dp(12));
        content.addView(countView, new LinearLayout.LayoutParams(MATCH, WRAP));
        listBody = new LinearLayout(c);
        listBody.setOrientation(LinearLayout.VERTICAL);
        content.addView(listBody, new LinearLayout.LayoutParams(MATCH, WRAP));
        listLayer.addView(sv, new FrameLayout.LayoutParams(MATCH, MATCH));

        TextView plus = new TextView(c);
        plus.setText("+");
        plus.setTextColor(Color.WHITE);
        plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f);
        plus.setGravity(Gravity.CENTER);
        GradientDrawable pb = new GradientDrawable();
        pb.setShape(GradientDrawable.OVAL);
        pb.setColor(YELLOW);
        plus.setBackground(pb);
        plus.setElevation(dp(6));
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor(-1);
            }
        });
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END);
        pl.rightMargin = dp(22);
        pl.bottomMargin = dp(34) + host.bottomInset() + dp(16);
        listLayer.addView(plus, pl);
        addView(listLayer, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- duzenleyici
        editorLayer = new LinearLayout(c);
        editorLayer.setOrientation(LinearLayout.VERTICAL);
        editorLayer.setBackgroundColor(BG);
        editorLayer.setVisibility(View.GONE);

        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(52), dp(16), dp(6));
        TextView back = label(c, "‹ Notlar", 17f, YELLOW, false);
        back.setPadding(dp(4), dp(6), dp(12), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeEditor(true);
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView del = label(c, "Sil", 17f, 0xFFFF3B30, false);
        del.setPadding(dp(12), dp(6), dp(4), dp(6));
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeEditor(false);
            }
        });
        bar.addView(del, new LinearLayout.LayoutParams(WRAP, WRAP));
        editorLayer.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        edit = new EditText(c);
        edit.setBackground(null);
        edit.setHint("Not yaz…");
        edit.setHintTextColor(0xFFAEAEB2);
        edit.setTextColor(0xFF000000);
        edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        edit.setPadding(dp(20), dp(8), dp(20), dp(34) + host.bottomInset());
        editorLayer.addView(edit, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        addView(editorLayer, new FrameLayout.LayoutParams(MATCH, MATCH));

        refreshList();
        addHomeBar(false);
    }

    @Override
    boolean darkStatus() {
        return true;
    }

    @Override
    boolean onBack() {
        if (editorLayer.getVisibility() == View.VISIBLE) {
            closeEditor(true);
            return true;
        }
        return false;
    }

    @Override
    void onClosing() {
        if (editorLayer.getVisibility() == View.VISIBLE) {
            saveCurrent();
            hideKeyboard();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnGlobalLayoutListener(keyboardListener);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalLayoutListener(keyboardListener);
    }

    // ------------------------------------------------------------------ veri

    private void load() {
        notes.clear();
        try {
            JSONArray arr = new JSONArray(prefs.getString("notes", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                notes.add(new Note(o.getString("t"), o.getLong("s")));
            }
        } catch (Exception ignored) {
        }
    }

    private void persist() {
        try {
            JSONArray arr = new JSONArray();
            for (Note n : notes) {
                JSONObject o = new JSONObject();
                o.put("t", n.text);
                o.put("s", n.ts);
                arr.put(o);
            }
            prefs.edit().putString("notes", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void saveCurrent() {
        String t = edit.getText().toString();
        if (t.trim().isEmpty()) {
            if (editing >= 0 && editing < notes.size()) {
                notes.remove(editing);
            }
        } else if (editing >= 0 && editing < notes.size()) {
            Note n = notes.remove(editing);
            n.text = t;
            n.ts = System.currentTimeMillis();
            notes.add(0, n);
        } else {
            notes.add(0, new Note(t, System.currentTimeMillis()));
        }
        editing = -1;
        persist();
    }

    // ------------------------------------------------------------------ gorunum

    private TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private String dateText(long ts) {
        Calendar a = Calendar.getInstance();
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(ts);
        boolean today = a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
                && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
        Locale tr = new Locale("tr", "TR");
        return new SimpleDateFormat(today ? "HH:mm" : "d MMM yyyy", tr).format(new Date(ts));
    }

    private void refreshList() {
        Context c = getContext();
        listBody.removeAllViews();
        countView.setText(notes.size() + " Not");
        if (notes.isEmpty()) {
            TextView empty = label(c, "Henüz not yok.\nSağ alttaki + ile başla.", 16f, 0xFF8E8E93, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(60), 0, 0);
            listBody.addView(empty, new LinearLayout.LayoutParams(MATCH, WRAP));
            return;
        }
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        card.setClipToOutline(true);
        card.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        for (int i = 0; i < notes.size(); i++) {
            final int idx = i;
            Note n = notes.get(i);
            String[] lines = n.text.trim().split("\n", 3);
            String first = lines[0].isEmpty() ? "Yeni Not" : lines[0];
            String second = lines.length > 1 ? lines[1] : "Ek metin yok";

            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(16), dp(12), dp(16), dp(12));
            TextView t1 = label(c, first, 17f, 0xFF000000, true);
            t1.setSingleLine(true);
            row.addView(t1, new LinearLayout.LayoutParams(MATCH, WRAP));
            TextView t2 = label(c, dateText(n.ts) + "   " + second, 14f, 0xFF8E8E93, false);
            t2.setSingleLine(true);
            row.addView(t2, new LinearLayout.LayoutParams(MATCH, WRAP));
            row.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    int a = e.getActionMasked();
                    if (a == MotionEvent.ACTION_DOWN) {
                        v.setBackgroundColor(0xFFD1D1D6);
                    } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                        v.setBackgroundColor(Color.TRANSPARENT);
                    }
                    return false;
                }
            });
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openEditor(idx);
                }
            });
            card.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
            if (i < notes.size() - 1) {
                View line = new View(c);
                line.setBackgroundColor(0xFFE5E5EA);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, 1);
                lp.leftMargin = dp(16);
                card.addView(line, lp);
            }
        }
        listBody.addView(card, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private void openEditor(int idx) {
        editing = idx;
        edit.setText(idx >= 0 && idx < notes.size() ? notes.get(idx).text : "");
        edit.setSelection(edit.getText().length());
        editorLayer.setAlpha(0f);
        editorLayer.setTranslationX(dp(40));
        editorLayer.setVisibility(View.VISIBLE);
        editorLayer.animate().alpha(1f).translationX(0f).setDuration(260).start();
        edit.requestFocus();
        edit.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT);
                }
            }
        }, 280);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(edit.getWindowToken(), 0);
        }
    }

    private void closeEditor(boolean save) {
        if (save) {
            saveCurrent();
        } else {
            if (editing >= 0 && editing < notes.size()) {
                notes.remove(editing);
            }
            editing = -1;
            persist();
        }
        hideKeyboard();
        refreshList();
        editorLayer.animate().alpha(0f).translationX(dp(40)).setDuration(220).withEndAction(new Runnable() {
            @Override
            public void run() {
                editorLayer.setVisibility(View.GONE);
            }
        }).start();
    }
}
