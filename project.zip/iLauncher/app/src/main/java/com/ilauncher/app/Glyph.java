package com.ilauncher.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Ayarlar ve Kontrol Merkezi icin koddan cizilen basit simgeler. Hicbir kaynak dosyasi gerekmez. */
final class Glyph {
    static final int WIFI = 0, BT = 1, MOBILE = 2, BELL = 3, SOUND = 4, SUN = 5, BATTERY = 6, STORAGE = 7,
            APPS = 8, LOCK = 9, INFO = 10, GEAR = 11, PLANE = 12, GLOBE = 13, HAND = 14, CLOCK = 15,
            HOME = 16, CALC = 17, NOTE = 18, CAMERA = 19, TORCH = 20, ROTATE = 21, DATA = 22;

    private static final Path PATH = new Path();
    private static final RectF RECT = new RectF();

    private Glyph() {
    }

    /** Renkli yuvarlak kare icinde beyaz simge (iPhone Ayarlar satir simgesi). */
    static Bitmap tile(int type, int color, int px) {
        Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(new RectF(0, 0, px, px), px * 0.225f, px * 0.225f, p);
        draw(c, type, px / 2f, px / 2f, px * 0.27f, p, Color.WHITE);
        return b;
    }

    private static void stroke(Paint p, float w) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
    }

    private static void fill(Paint p) {
        p.setStyle(Paint.Style.FILL);
    }

    private static void poly(Canvas c, Paint p, float cx, float cy, float s, boolean close, float... pts) {
        PATH.reset();
        for (int i = 0; i + 1 < pts.length; i += 2) {
            float x = cx + pts[i] * s;
            float y = cy + pts[i + 1] * s;
            if (i == 0) {
                PATH.moveTo(x, y);
            } else {
                PATH.lineTo(x, y);
            }
        }
        if (close) {
            PATH.close();
        }
        c.drawPath(PATH, p);
    }

    private static void line(Canvas c, Paint p, float cx, float cy, float s, float x1, float y1, float x2, float y2) {
        c.drawLine(cx + x1 * s, cy + y1 * s, cx + x2 * s, cy + y2 * s, p);
    }

    private static void rr(Canvas c, Paint p, float cx, float cy, float s,
                           float l, float t, float r, float b, float radius) {
        RECT.set(cx + l * s, cy + t * s, cx + r * s, cy + b * s);
        c.drawRoundRect(RECT, radius * s, radius * s, p);
    }

    /** s: simgenin yari boyutu (piksel). */
    static void draw(Canvas c, int type, float cx, float cy, float s, Paint p, int color) {
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        switch (type) {
            case WIFI: {
                stroke(p, s * 0.2f);
                float by = cy + s * 0.7f;
                float[] radii = {0.55f, 1.05f, 1.55f};
                for (float r : radii) {
                    RECT.set(cx - r * s, by - r * s, cx + r * s, by + r * s);
                    c.drawArc(RECT, 225f, 90f, false, p);
                }
                fill(p);
                c.drawCircle(cx, by, s * 0.16f, p);
                break;
            }
            case BT:
                stroke(p, s * 0.17f);
                poly(c, p, cx, cy, s, false, -0.55f, -0.45f, 0.55f, 0.45f, 0f, 1f, 0f, -1f, 0.55f, -0.45f, -0.55f, 0.45f);
                break;
            case MOBILE:
                fill(p);
                for (int i = 0; i < 4; i++) {
                    float h = 0.45f + 0.4f * i;
                    rr(c, p, cx, cy, s, -0.95f + i * 0.5f, 0.85f - h, -0.95f + i * 0.5f + 0.34f, 0.85f, 0.08f);
                }
                break;
            case BELL:
                fill(p);
                c.drawCircle(cx, cy - 0.2f * s, 0.6f * s, p);
                rr(c, p, cx, cy, s, -0.85f, 0.1f, 0.85f, 0.55f, 0.2f);
                c.drawCircle(cx, cy + 0.85f * s, 0.2f * s, p);
                break;
            case SOUND:
                fill(p);
                poly(c, p, cx, cy, s, true, -0.95f, -0.3f, -0.5f, -0.3f, 0.05f, -0.8f, 0.05f, 0.8f, -0.5f, 0.3f, -0.95f, 0.3f);
                stroke(p, s * 0.16f);
                for (float r : new float[]{0.55f, 0.95f}) {
                    RECT.set(cx + 0.05f * s - r * s, cy - r * s, cx + 0.05f * s + r * s, cy + r * s);
                    c.drawArc(RECT, -45f, 90f, false, p);
                }
                break;
            case SUN:
                fill(p);
                c.drawCircle(cx, cy, 0.42f * s, p);
                stroke(p, s * 0.15f);
                for (int i = 0; i < 8; i++) {
                    double a = Math.toRadians(i * 45.0);
                    float cs = (float) Math.cos(a);
                    float sn = (float) Math.sin(a);
                    line(c, p, cx, cy, s, cs * 0.68f, sn * 0.68f, cs * 0.97f, sn * 0.97f);
                }
                break;
            case BATTERY:
                stroke(p, s * 0.13f);
                rr(c, p, cx, cy, s, -1.0f, -0.5f, 0.8f, 0.5f, 0.2f);
                fill(p);
                rr(c, p, cx, cy, s, 0.85f, -0.18f, 1.0f, 0.18f, 0.05f);
                rr(c, p, cx, cy, s, -0.82f, -0.32f, 0.3f, 0.32f, 0.08f);
                break;
            case STORAGE:
                stroke(p, s * 0.14f);
                rr(c, p, cx, cy, s, -0.95f, -0.55f, 0.95f, 0.55f, 0.25f);
                line(c, p, cx, cy, s, -0.95f, 0.1f, 0.95f, 0.1f);
                fill(p);
                c.drawCircle(cx + 0.6f * s, cy + 0.33f * s, 0.08f * s, p);
                break;
            case APPS:
                fill(p);
                rr(c, p, cx, cy, s, -0.9f, -0.9f, -0.1f, -0.1f, 0.2f);
                rr(c, p, cx, cy, s, 0.1f, -0.9f, 0.9f, -0.1f, 0.2f);
                rr(c, p, cx, cy, s, -0.9f, 0.1f, -0.1f, 0.9f, 0.2f);
                rr(c, p, cx, cy, s, 0.1f, 0.1f, 0.9f, 0.9f, 0.2f);
                break;
            case LOCK:
                fill(p);
                rr(c, p, cx, cy, s, -0.7f, -0.05f, 0.7f, 0.9f, 0.18f);
                stroke(p, s * 0.16f);
                RECT.set(cx - 0.42f * s, cy - 0.95f * s, cx + 0.42f * s, cy - 0.1f * s);
                c.drawArc(RECT, 180f, 180f, false, p);
                line(c, p, cx, cy, s, -0.42f, -0.53f, -0.42f, 0f);
                line(c, p, cx, cy, s, 0.42f, -0.53f, 0.42f, 0f);
                break;
            case INFO:
                stroke(p, s * 0.14f);
                c.drawCircle(cx, cy, 0.85f * s, p);
                fill(p);
                c.drawCircle(cx, cy - 0.4f * s, 0.1f * s, p);
                stroke(p, s * 0.16f);
                line(c, p, cx, cy, s, 0f, -0.08f, 0f, 0.45f);
                break;
            case GEAR:
                stroke(p, s * 0.17f);
                c.drawCircle(cx, cy, 0.45f * s, p);
                stroke(p, s * 0.2f);
                for (int i = 0; i < 8; i++) {
                    double a = Math.toRadians(i * 45.0);
                    float cs = (float) Math.cos(a);
                    float sn = (float) Math.sin(a);
                    line(c, p, cx, cy, s, cs * 0.68f, sn * 0.68f, cs * 0.95f, sn * 0.95f);
                }
                break;
            case PLANE:
                fill(p);
                poly(c, p, cx, cy, s, true, 0f, -1f, 0.14f, -0.35f, 1f, 0.2f, 1f, 0.45f, 0.14f, 0.15f, 0.1f, 0.7f,
                        0.4f, 0.9f, 0.4f, 1.05f, 0f, 0.95f, -0.4f, 1.05f, -0.4f, 0.9f, -0.1f, 0.7f, -0.14f, 0.15f,
                        -1f, 0.45f, -1f, 0.2f, -0.14f, -0.35f);
                break;
            case GLOBE:
                stroke(p, s * 0.12f);
                c.drawCircle(cx, cy, 0.85f * s, p);
                RECT.set(cx - 0.4f * s, cy - 0.85f * s, cx + 0.4f * s, cy + 0.85f * s);
                c.drawOval(RECT, p);
                line(c, p, cx, cy, s, -0.85f, 0f, 0.85f, 0f);
                break;
            case HAND:
                stroke(p, s * 0.12f);
                c.drawCircle(cx, cy, 0.85f * s, p);
                fill(p);
                c.drawCircle(cx, cy - 0.45f * s, 0.12f * s, p);
                stroke(p, s * 0.13f);
                line(c, p, cx, cy, s, -0.5f, -0.15f, 0.5f, -0.15f);
                line(c, p, cx, cy, s, 0f, -0.15f, -0.3f, 0.55f);
                line(c, p, cx, cy, s, 0f, -0.15f, 0.3f, 0.55f);
                break;
            case CLOCK:
                stroke(p, s * 0.14f);
                c.drawCircle(cx, cy, 0.85f * s, p);
                line(c, p, cx, cy, s, 0f, 0f, 0f, -0.5f);
                line(c, p, cx, cy, s, 0f, 0f, 0.4f, 0.2f);
                break;
            case HOME:
                fill(p);
                poly(c, p, cx, cy, s, true, -0.95f, 0f, 0f, -0.9f, 0.95f, 0f, 0.6f, 0f, 0.6f, 0.85f, -0.6f, 0.85f, -0.6f, 0f);
                break;
            case CALC:
                stroke(p, s * 0.13f);
                rr(c, p, cx, cy, s, -0.7f, -0.95f, 0.7f, 0.95f, 0.2f);
                fill(p);
                rr(c, p, cx, cy, s, -0.45f, -0.7f, 0.45f, -0.35f, 0.06f);
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        c.drawCircle(cx + (-0.27f + j * 0.54f) * s, cy + (0.1f + i * 0.45f) * s, 0.11f * s, p);
                    }
                }
                break;
            case NOTE:
                stroke(p, s * 0.13f);
                rr(c, p, cx, cy, s, -0.75f, -0.95f, 0.75f, 0.95f, 0.2f);
                line(c, p, cx, cy, s, -0.4f, -0.4f, 0.4f, -0.4f);
                line(c, p, cx, cy, s, -0.4f, 0f, 0.4f, 0f);
                line(c, p, cx, cy, s, -0.4f, 0.4f, 0.1f, 0.4f);
                break;
            case CAMERA:
                stroke(p, s * 0.13f);
                rr(c, p, cx, cy, s, -0.95f, -0.55f, 0.95f, 0.7f, 0.22f);
                c.drawCircle(cx, cy + 0.08f * s, 0.35f * s, p);
                line(c, p, cx, cy, s, -0.3f, -0.8f, 0.3f, -0.8f);
                break;
            case TORCH:
                fill(p);
                rr(c, p, cx, cy, s, -0.5f, -0.95f, 0.5f, -0.45f, 0.12f);
                rr(c, p, cx, cy, s, -0.3f, -0.4f, 0.3f, 0.95f, 0.12f);
                break;
            case ROTATE:
                stroke(p, s * 0.15f);
                RECT.set(cx - 0.85f * s, cy - 0.85f * s, cx + 0.85f * s, cy + 0.85f * s);
                c.drawArc(RECT, 40f, 280f, false, p);
                fill(p);
                rr(c, p, cx, cy, s, -0.28f, -0.1f, 0.28f, 0.35f, 0.06f);
                stroke(p, s * 0.1f);
                RECT.set(cx - 0.16f * s, cy - 0.38f * s, cx + 0.16f * s, cy + 0.0f * s);
                c.drawArc(RECT, 180f, 180f, false, p);
                break;
            case DATA:
                stroke(p, s * 0.15f);
                line(c, p, cx, cy, s, -0.4f, 0.8f, -0.4f, -0.7f);
                poly(c, p, cx, cy, s, false, -0.75f, -0.35f, -0.4f, -0.75f, -0.05f, -0.35f);
                line(c, p, cx, cy, s, 0.4f, -0.8f, 0.4f, 0.7f);
                poly(c, p, cx, cy, s, false, 0.05f, 0.35f, 0.4f, 0.75f, 0.75f, 0.35f);
                break;
            default:
                break;
        }
    }
}
