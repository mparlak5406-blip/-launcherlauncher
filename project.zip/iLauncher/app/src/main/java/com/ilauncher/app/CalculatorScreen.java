package com.ilauncher.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** iPhone tarzi hesap makinesi. */
final class CalculatorScreen extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int GRAY = 0xFFA5A5A5;
    private static final int DARK = 0xFF333333;
    private static final int ORANGE = 0xFFFF9F0A;

    private final TextView display;
    private final TextView acButton;
    private final Map<String, TextView> opButtons = new HashMap<>();

    private double acc;
    private String entry = "0";
    private String pending;
    private boolean fresh = true;

    CalculatorScreen(Context c, Host h) {
        super(c, h);
        setBackgroundColor(Color.BLACK);

        int screenW = c.getResources().getDisplayMetrics().widthPixels;
        int gap = dp(12);
        int size = (screenW - 5 * gap) / 4;

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(52), 0, dp(34) + host.bottomInset() + dp(8));

        display = new TextView(c);
        display.setTextColor(Color.WHITE);
        display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setSingleLine(true);
        display.setPadding(dp(24), 0, dp(24), dp(8));
        display.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        col.addView(display, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        String[][] rows = {
                {"AC", "±", "%", "÷"},
                {"7", "8", "9", "×"},
                {"4", "5", "6", "−"},
                {"1", "2", "3", "+"},
                {"0", ",", "="}
        };
        TextView ac = null;
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(gap, 0, 0, gap);
            for (String key : r) {
                boolean zero = key.equals("0");
                int w = zero ? 2 * size + gap : size;
                TextView b = button(c, key, size, zero);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, size);
                lp.rightMargin = gap;
                row.addView(b, lp);
                if (key.equals("AC")) {
                    ac = b;
                }
                if (isOp(key)) {
                    opButtons.put(key, b);
                }
            }
            col.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        acButton = ac;
        addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
        refresh();
        addHomeBar(true);
    }

    @Override
    boolean darkStatus() {
        return false;
    }

    private boolean isOp(String k) {
        return k.equals("÷") || k.equals("×") || k.equals("−") || k.equals("+") || k.equals("=");
    }

    private TextView button(Context c, final String key, int size, boolean wide) {
        final TextView b = new TextView(c);
        b.setText(key);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f);
        final int bg;
        final int fg;
        if (isOp(key)) {
            bg = ORANGE;
            fg = Color.WHITE;
        } else if (key.equals("AC") || key.equals("±") || key.equals("%")) {
            bg = GRAY;
            fg = Color.BLACK;
        } else {
            bg = DARK;
            fg = Color.WHITE;
        }
        b.setTextColor(fg);
        b.setTag(new int[]{bg, fg});
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(size / 2f);
        b.setBackground(g);
        if (wide) {
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setPadding(Math.round(size * 0.38f), 0, 0, 0);
        } else {
            b.setGravity(Gravity.CENTER);
        }
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.65f);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.animate().alpha(1f).setDuration(220).start();
                }
                return false;
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                press(key);
            }
        });
        return b;
    }

    // ------------------------------------------------------------------ hesap mantigi

    private void press(String k) {
        if (entry.equals("Hata") && !k.equals("AC")) {
            return;
        }
        switch (k) {
            case "AC":
                clear();
                break;
            case "±":
                if (entry.startsWith("-")) {
                    entry = entry.substring(1);
                } else if (!entry.equals("0")) {
                    entry = "-" + entry;
                }
                break;
            case "%":
                entry = format(parse(entry) / 100.0);
                fresh = true;
                break;
            case ",":
                if (fresh) {
                    entry = "0.";
                    fresh = false;
                } else if (!entry.contains(".")) {
                    entry = entry + ".";
                }
                break;
            case "=":
                equals();
                break;
            case "+":
            case "−":
            case "×":
            case "÷":
                operator(k);
                break;
            default:
                digit(k);
                break;
        }
        refresh();
    }

    private void digit(String d) {
        if (fresh) {
            entry = d;
            fresh = false;
            return;
        }
        if (entry.equals("0")) {
            entry = d;
        } else if (entry.equals("-0")) {
            entry = "-" + d;
        } else if (digitCount(entry) < 9) {
            entry = entry + d;
        }
    }

    private int digitCount(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            if (Character.isDigit(s.charAt(i))) {
                n++;
            }
        }
        return n;
    }

    private void operator(String op) {
        if (pending != null && !fresh) {
            acc = apply(acc, pending, parse(entry));
            entry = format(acc);
        } else {
            acc = parse(entry);
        }
        pending = op;
        fresh = true;
    }

    private void equals() {
        if (pending != null) {
            acc = apply(acc, pending, parse(entry));
            entry = format(acc);
            pending = null;
            fresh = true;
        }
    }

    private void clear() {
        if (!entry.equals("0") && !fresh) {
            entry = "0";
        } else {
            acc = 0;
            entry = "0";
            pending = null;
            fresh = true;
        }
    }

    private double apply(double a, String op, double b) {
        switch (op) {
            case "+":
                return a + b;
            case "−":
                return a - b;
            case "×":
                return a * b;
            case "÷":
                return b == 0 ? Double.NaN : a / b;
            default:
                return b;
        }
    }

    private double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    private String format(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return "Hata";
        }
        if (Math.abs(v) >= 1e9 || (v != 0 && Math.abs(v) < 1e-8)) {
            return String.format(Locale.US, "%.4e", v);
        }
        String s = new BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        if (s.equals("-0")) {
            s = "0";
        }
        return s;
    }

    // ------------------------------------------------------------------ ekran

    private String shown() {
        if (entry.equals("Hata") || entry.contains("e")) {
            return entry;
        }
        boolean neg = entry.startsWith("-");
        String body = neg ? entry.substring(1) : entry;
        int dot = body.indexOf('.');
        String intPart = dot >= 0 ? body.substring(0, dot) : body;
        String frac = dot >= 0 ? "," + body.substring(dot + 1) : "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < intPart.length(); i++) {
            if (i > 0 && (intPart.length() - i) % 3 == 0) {
                sb.append('.');
            }
            sb.append(intPart.charAt(i));
        }
        return (neg ? "-" : "") + sb + frac;
    }

    private void refresh() {
        String s = shown();
        display.setText(s);
        int len = s.length();
        float sp = len <= 6 ? 88f : len <= 8 ? 76f : len <= 10 ? 64f : len <= 12 ? 54f : 46f;
        display.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);

        boolean clearEntry = !entry.equals("0") && !fresh;
        acButton.setText(clearEntry ? "C" : "AC");

        for (Map.Entry<String, TextView> en : opButtons.entrySet()) {
            TextView b = en.getValue();
            boolean active = pending != null && fresh && en.getKey().equals(pending);
            GradientDrawable g = (GradientDrawable) b.getBackground();
            g.setColor(active ? Color.WHITE : ORANGE);
            b.setTextColor(active ? ORANGE : Color.WHITE);
        }
    }
}
