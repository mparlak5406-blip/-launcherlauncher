package com.ilauncher.app;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** iPhone tarzi Kontrol Merkezi: gercek fener, parlaklik, ses ve baglanti kisayollari. */
final class ControlCenter extends ScreenBase {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int TILE = 0xCC2C2C2E;
    private static final int OFF = 0xFF48484A;
    private static final int BLUE = 0xFF0A84FF;
    private static final int GREEN = 0xFF30D158;
    private static final int ORANGE = 0xFFFF9F0A;

    private final Context ctx;
    private final int gap;
    private final int unit;

    private ImageView wifiBtn;
    private ImageView btBtn;
    private ImageView dataBtn;
    private ImageView planeBtn;
    private FrameLayout torchTile;
    private FrameLayout rotateTile;

    private CameraManager cam;
    private CameraManager.TorchCallback torchCb;
    private String torchId;
    private boolean torchOn;

    ControlCenter(Context c, Host h) {
        super(c, h);
        ctx = c;
        setBackgroundColor(0xB3000000);
        setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.closeScreen(ControlCenter.this);
            }
        });

        int screenW = c.getResources().getDisplayMetrics().widthPixels;
        gap = dp(12);
        int side = dp(18);
        unit = (screenW - 2 * side - 3 * gap) / 4;

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(side, dp(64), side, 0);

        // ---- 1. satir: baglanti blogu + parlaklik + ses
        LinearLayout row1 = new LinearLayout(c);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        int block = 2 * unit + gap;
        row1.addView(connectivityBlock(c, block), new LinearLayout.LayoutParams(block, block));

        VSlider bright = new VSlider(c, Glyph.SUN, readBrightness(), new VSlider.OnChange() {
            @Override
            public void onChange(float v) {
                setBrightness(v);
            }
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(unit, block);
        bl.leftMargin = gap;
        row1.addView(bright, bl);

        VSlider vol = new VSlider(c, Glyph.SOUND, readVolume(), new VSlider.OnChange() {
            @Override
            public void onChange(float v) {
                setVolume(v);
            }
        });
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(unit, block);
        vl.leftMargin = gap;
        row1.addView(vol, vl);
        col.addView(row1, new LinearLayout.LayoutParams(MATCH, block));

        // ---- 2. satir: kisayollar
        LinearLayout row2 = new LinearLayout(c);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        torchTile = tile(c, Glyph.TORCH, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleTorch();
            }
        });
        FrameLayout calcTile = tile(c, Glyph.CALC, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.closeScreen(ControlCenter.this);
                host.openInternal(2, null);
            }
        });
        FrameLayout noteTile = tile(c, Glyph.NOTE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.closeScreen(ControlCenter.this);
                host.openInternal(3, null);
            }
        });
        FrameLayout camTile = tile(c, Glyph.CAMERA, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.closeScreen(ControlCenter.this);
                host.launchIntent(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
            }
        });
        View[] tiles = {torchTile, calcTile, noteTile, camTile};
        for (int i = 0; i < tiles.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(unit, unit);
            if (i > 0) {
                lp.leftMargin = gap;
            }
            row2.addView(tiles[i], lp);
        }
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(MATCH, unit);
        r2.topMargin = gap;
        col.addView(row2, r2);

        // ---- 3. satir: genis kutular
        LinearLayout row3 = new LinearLayout(c);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        int wide = 2 * unit + gap;
        FrameLayout settingsTile = wideTile(c, Glyph.GEAR, "Ayarlar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.closeScreen(ControlCenter.this);
                host.openInternal(1, null);
            }
        });
        rotateTile = wideTile(c, Glyph.ROTATE, "Dönme Kilidi", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRotation();
            }
        });
        row3.addView(settingsTile, new LinearLayout.LayoutParams(wide, unit));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(wide, unit);
        rl.leftMargin = gap;
        row3.addView(rotateTile, rl);
        LinearLayout.LayoutParams r3 = new LinearLayout.LayoutParams(MATCH, unit);
        r3.topMargin = gap;
        col.addView(row3, r3);

        addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
        addHomeBar(true);

        initTorch();
        refresh();
    }

    @Override
    boolean darkStatus() {
        return false;
    }

    @Override
    boolean translucent() {
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        try {
            if (cam != null && torchCb != null) {
                cam.unregisterTorchCallback(torchCb);
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ gorunum parcalari

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private Bitmap glyphBitmap(int glyph, int color, int px) {
        Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Glyph.draw(new Canvas(b), glyph, px / 2f, px / 2f, px * 0.3f, p, color);
        return b;
    }

    private FrameLayout tile(Context c, int glyph, View.OnClickListener l) {
        FrameLayout t = new FrameLayout(c);
        t.setBackground(rounded(TILE, dp(24)));
        ImageView iv = new ImageView(c);
        iv.setImageBitmap(glyphBitmap(glyph, Color.WHITE, dp(44)));
        t.addView(iv, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER));
        t.setTag(Integer.valueOf(glyph));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    private FrameLayout wideTile(Context c, int glyph, String label, View.OnClickListener l) {
        FrameLayout t = new FrameLayout(c);
        t.setBackground(rounded(TILE, dp(24)));
        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.HORIZONTAL);
        in.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(c);
        iv.setImageBitmap(glyphBitmap(glyph, Color.WHITE, dp(40)));
        in.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView tv = new TextView(c);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
        tl.leftMargin = dp(8);
        in.addView(tv, tl);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(WRAP, MATCH, Gravity.CENTER_VERTICAL | Gravity.START);
        fl.leftMargin = dp(18);
        t.addView(in, fl);
        t.setTag(Integer.valueOf(glyph));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    private void press(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(100).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).start();
                }
                return false;
            }
        });
    }

    private View connectivityBlock(Context c, int size) {
        LinearLayout block = new LinearLayout(c);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setBackground(rounded(TILE, dp(28)));
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout bottom = new LinearLayout(c);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        block.addView(top, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        block.addView(bottom, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        planeBtn = circle(c, Glyph.PLANE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(Settings.ACTION_AIRPLANE_MODE_SETTINGS);
            }
        });
        dataBtn = circle(c, Glyph.DATA, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(Settings.ACTION_DATA_ROAMING_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS);
            }
        });
        wifiBtn = circle(c, Glyph.WIFI, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY, Settings.ACTION_WIFI_SETTINGS);
            }
        });
        btBtn = circle(c, Glyph.BT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(Settings.ACTION_BLUETOOTH_SETTINGS);
            }
        });
        top.addView(cell(c, planeBtn), new LinearLayout.LayoutParams(0, MATCH, 1f));
        top.addView(cell(c, dataBtn), new LinearLayout.LayoutParams(0, MATCH, 1f));
        bottom.addView(cell(c, wifiBtn), new LinearLayout.LayoutParams(0, MATCH, 1f));
        bottom.addView(cell(c, btBtn), new LinearLayout.LayoutParams(0, MATCH, 1f));
        return block;
    }

    private FrameLayout cell(Context c, View child) {
        FrameLayout f = new FrameLayout(c);
        int d2 = Math.round(unit * 0.8f);
        f.addView(child, new FrameLayout.LayoutParams(d2, d2, Gravity.CENTER));
        return f;
    }

    private ImageView circle(Context c, int glyph, View.OnClickListener l) {
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        iv.setTag(Integer.valueOf(glyph));
        iv.setOnClickListener(l);
        press(iv);
        return iv;
    }

    private void paintCircle(ImageView iv, boolean on, int onColor) {
        int glyph = ((Integer) iv.getTag()).intValue();
        iv.setBackground(rounded(on ? onColor : OFF, 1000f));
        iv.setImageBitmap(glyphBitmap(glyph, Color.WHITE, dp(40)));
    }

    private void paintTile(FrameLayout t, boolean on, int onColor) {
        t.setBackground(rounded(on ? onColor : TILE, dp(24)));
    }

    // ------------------------------------------------------------------ durumlar

    private void refresh() {
        boolean wifi = false;
        boolean bt = false;
        boolean data = false;
        boolean plane = false;
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifi = wm != null && wm.isWifiEnabled();
        } catch (Throwable ignored) {
        }
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            bt = ad != null && ad.isEnabled();
        } catch (Throwable ignored) {
        }
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            data = tm != null && tm.isDataEnabled();
        } catch (Throwable ignored) {
        }
        try {
            plane = Settings.Global.getInt(ctx.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        } catch (Throwable ignored) {
        }
        paintCircle(wifiBtn, wifi, BLUE);
        paintCircle(btBtn, bt, BLUE);
        paintCircle(dataBtn, data, GREEN);
        paintCircle(planeBtn, plane, ORANGE);
        paintTile(torchTile, torchOn, Color.WHITE);
        ((ImageView) ((FrameLayout) torchTile).getChildAt(0)).setImageBitmap(
                glyphBitmap(Glyph.TORCH, torchOn ? 0xFF1C1C1E : Color.WHITE, dp(44)));
        boolean locked = false;
        try {
            locked = Settings.System.getInt(ctx.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 1) == 0;
        } catch (Throwable ignored) {
        }
        paintTile(rotateTile, locked, 0xFFFF453A);
    }

    private void open(String... actions) {
        for (String a : actions) {
            if (host.launchIntent(new Intent(a))) {
                host.closeScreen(this);
                return;
            }
        }
        Toast.makeText(ctx, "Açılamadı", Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ fener

    private void initTorch() {
        try {
            cam = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cam.getCameraIdList()) {
                CameraCharacteristics ch = cam.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (flash != null && flash.booleanValue() && facing != null
                        && facing.intValue() == CameraCharacteristics.LENS_FACING_BACK) {
                    torchId = id;
                    break;
                }
            }
            torchCb = new CameraManager.TorchCallback() {
                @Override
                public void onTorchModeChanged(String cameraId, boolean enabled) {
                    if (cameraId.equals(torchId)) {
                        torchOn = enabled;
                        refresh();
                    }
                }
            };
            cam.registerTorchCallback(torchCb, null);
        } catch (Throwable t) {
            torchId = null;
        }
    }

    private void toggleTorch() {
        if (cam == null || torchId == null) {
            Toast.makeText(ctx, "Fener bulunamadı", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            cam.setTorchMode(torchId, !torchOn);
        } catch (Throwable t) {
            Toast.makeText(ctx, "Fener açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ parlaklik, ses, donme

    private boolean canWriteSettings() {
        if (Settings.System.canWrite(ctx)) {
            return true;
        }
        Toast.makeText(ctx, "İzin ver, sonra geri dön", Toast.LENGTH_LONG).show();
        Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.getPackageName()));
        host.launchIntent(i);
        return false;
    }

    private float readBrightness() {
        try {
            return Settings.System.getInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128) / 255f;
        } catch (Throwable t) {
            return 0.5f;
        }
    }

    private long lastAsk;

    private void setBrightness(float v) {
        if (!Settings.System.canWrite(ctx)) {
            long now = System.currentTimeMillis();
            if (now - lastAsk > 4000) {
                lastAsk = now;
                canWriteSettings();
            }
            return;
        }
        try {
            Settings.System.putInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
                    Math.max(1, Math.min(255, Math.round(v * 255f))));
        } catch (Throwable ignored) {
        }
    }

    private float readVolume() {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            return max == 0 ? 0f : am.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) max;
        } catch (Throwable t) {
            return 0.5f;
        }
    }

    private void setVolume(float v) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0);
        } catch (Throwable ignored) {
        }
    }

    private void toggleRotation() {
        if (!canWriteSettings()) {
            return;
        }
        try {
            int cur = Settings.System.getInt(ctx.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 1);
            Settings.System.putInt(ctx.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, cur == 1 ? 0 : 1);
        } catch (Throwable ignored) {
        }
        refresh();
    }

    // ------------------------------------------------------------------ dikey kaydirici

    /** iPhone'daki gibi yukari surukleyince dolan dikey cubuk. */
    private static final class VSlider extends View {
        interface OnChange {
            void onChange(float v);
        }

        private final int glyph;
        private final OnChange cb;
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final RectF rect = new RectF();
        private final float dens;
        private float value;

        VSlider(Context c, int glyph, float init, OnChange cb) {
            super(c);
            this.glyph = glyph;
            this.cb = cb;
            this.value = Math.max(0f, Math.min(1f, init));
            dens = c.getResources().getDisplayMetrics().density;
            bg.setColor(TILE);
            fg.setColor(0xFFF2F2F7);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float r = 28f * dens;
            rect.set(0, 0, w, h);
            c.drawRoundRect(rect, r, r, bg);
            clip.reset();
            clip.addRoundRect(rect, r, r, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            float top = h - h * value;
            c.drawRect(0, top, w, h, fg);
            c.restore();
            boolean covered = h * value > 48f * dens;
            Glyph.draw(c, glyph, w / 2f, h - 30f * dens, 11f * dens, ic, covered ? 0xFF6E6E73 : Color.WHITE);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (getParent() != null) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    update(e.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    update(e.getY());
                    return true;
                default:
                    return true;
            }
        }

        private void update(float y) {
            float h = Math.max(1f, getHeight());
            value = Math.max(0f, Math.min(1f, 1f - y / h));
            cb.onChange(value);
            invalidate();
        }
    }
}
