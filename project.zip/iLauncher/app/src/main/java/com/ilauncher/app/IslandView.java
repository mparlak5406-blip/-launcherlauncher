package com.ilauncher.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Dynamic Island benzeri siyah hap. Dokununca genisleyip pil bilgisini gosterir. */
final class IslandView extends View {
    private static final float TOP_DP = 10f;

    private final float d;
    private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Runnable collapse = new Runnable() {
        @Override
        public void run() {
            animateTo(0f);
        }
    };
    private float expand;
    private ValueAnimator anim;
    private String info = "";

    IslandView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        pill.setColor(Color.BLACK);
        text.setColor(Color.WHITE);
        text.setTextSize(14f * d);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                removeCallbacks(collapse);
                if (expand < 0.5f) {
                    animateTo(1f);
                    postDelayed(collapse, 2600);
                } else {
                    animateTo(0f);
                }
            }
        });
    }

    void setBattery(int pct, boolean charging) {
        info = (charging ? "Şarj oluyor  %" : "Pil  %") + pct;
        invalidate();
    }

    private void animateTo(float target) {
        if (anim != null) {
            anim.cancel();
        }
        anim = ValueAnimator.ofFloat(expand, target);
        anim.setDuration(320);
        anim.setInterpolator(new DecelerateInterpolator(1.8f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                expand = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    private RectF pillRect() {
        float w = (104f + (210f - 104f) * expand) * d;
        float h = (30f + (46f - 30f) * expand) * d;
        float cx = getWidth() / 2f;
        float top = TOP_DP * d;
        return new RectF(cx - w / 2f, top, cx + w / 2f, top + h);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN && !pillRect().contains(e.getX(), e.getY())) {
            return false;
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        RectF r = pillRect();
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, pill);
        if (expand > 0.55f) {
            text.setAlpha(Math.round(255 * Math.min(1f, (expand - 0.55f) / 0.45f)));
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(info, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, text);
        }
    }
}
