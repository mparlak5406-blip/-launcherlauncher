package com.ilauncher.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.View;
import android.view.animation.PathInterpolator;

/** Yatay kaydirilan sayfalar. Asagi cekme hareketini de algilar (arama icin). */
final class PagerLayout extends ViewGroup {

    interface Listener {
        void onPageSelected(int index);

        void onPullDown();
    }

    private Listener listener;
    private int page;
    private float downX;
    private float downY;
    private float startScroll;
    private boolean dragging;
    private boolean pulling;
    private VelocityTracker tracker;
    private ValueAnimator anim;
    private final int slop;
    private final float minFling;
    private final float density;

    PagerLayout(Context context) {
        super(context);
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        density = context.getResources().getDisplayMetrics().density;
        minFling = 500f * density;
    }

    void setListener(Listener l) {
        listener = l;
    }

    int getPage() {
        return page;
    }

    void setPage(int index, boolean animate) {
        int count = getChildCount();
        if (count == 0) {
            page = 0;
            return;
        }
        int target = Math.max(0, Math.min(count - 1, index));
        if (animate) {
            animateTo(target);
        } else {
            if (anim != null) {
                anim.cancel();
            }
            page = target;
            scrollTo(target * getWidth(), 0);
        }
    }

    private void animateTo(int target) {
        if (anim != null) {
            anim.cancel();
        }
        int from = getScrollX();
        int to = target * getWidth();
        page = target;
        anim = ValueAnimator.ofInt(from, to);
        anim.setDuration(380);
        anim.setInterpolator(new PathInterpolator(0.22f, 1f, 0.36f, 1f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                scrollTo((Integer) a.getAnimatedValue(), 0);
            }
        });
        anim.start();
        if (listener != null) {
            listener.onPageSelected(target);
        }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(w, h);
        int cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY);
        int ch = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY);
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).measure(cw, ch);
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l;
        int h = b - t;
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).layout(i * w, 0, (i + 1) * w, h);
        }
        boolean animating = anim != null && anim.isRunning();
        if (!animating && !dragging) {
            scrollTo(page * w, 0);
        }
        applyEffects();
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        applyEffects();
    }

    /** Sayfalar kayarken hafif kuculur, solar ve yavas kayar (derinlik hissi). */
    private void applyEffects() {
        int w = getWidth();
        if (w == 0) {
            return;
        }
        float sx = getScrollX();
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            float off = (i * (float) w - sx) / w;
            float a = Math.min(1f, Math.abs(off));
            v.setAlpha(1f - 0.65f * a);
            float s = 1f - 0.12f * a;
            v.setScaleX(s);
            v.setScaleY(s);
            v.setTranslationX(-off * w * 0.18f);
        }
    }

    private void detect(MotionEvent e) {
        float dx = e.getX() - downX;
        float dy = e.getY() - downY;
        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) {
            dragging = true;
            startScroll = getScrollX();
            downX = e.getX();
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
        } else if (dy > slop && dy > Math.abs(dx) * 1.5f) {
            pulling = true;
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                dragging = false;
                pulling = false;
                if (tracker != null) {
                    tracker.recycle();
                }
                tracker = VelocityTracker.obtain();
                tracker.addMovement(e);
                if (anim != null && anim.isRunning()) {
                    anim.cancel();
                    dragging = true;
                    startScroll = getScrollX();
                    return true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (tracker != null) {
                    tracker.addMovement(e);
                }
                if (!dragging && !pulling) {
                    detect(e);
                }
                return dragging || pulling;
            default:
                return false;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (tracker == null) {
            tracker = VelocityTracker.obtain();
        }
        tracker.addMovement(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging && !pulling) {
                    detect(e);
                }
                if (dragging) {
                    float target = startScroll - (e.getX() - downX);
                    float max = (getChildCount() - 1) * (float) getWidth();
                    if (target < 0) {
                        target = target / 3f;
                    } else if (target > max) {
                        target = max + (target - max) / 3f;
                    }
                    scrollTo(Math.round(target), 0);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                finishGesture(e);
                return true;
            default:
                return true;
        }
    }

    private void finishGesture(MotionEvent e) {
        tracker.computeCurrentVelocity(1000);
        float vx = tracker.getXVelocity();
        tracker.recycle();
        tracker = null;

        if (dragging) {
            int w = Math.max(1, getWidth());
            float pos = getScrollX() / (float) w;
            int target;
            if (Math.abs(vx) > minFling) {
                target = vx < 0 ? (int) Math.floor(pos) + 1 : (int) Math.ceil(pos) - 1;
            } else {
                target = Math.round(pos);
            }
            target = Math.max(0, Math.min(getChildCount() - 1, target));
            animateTo(target);
        } else if (pulling && e.getActionMasked() == MotionEvent.ACTION_UP
                && e.getY() - downY > 70f * density) {
            if (listener != null) {
                listener.onPullDown();
            }
        }
        dragging = false;
        pulling = false;
    }
}
