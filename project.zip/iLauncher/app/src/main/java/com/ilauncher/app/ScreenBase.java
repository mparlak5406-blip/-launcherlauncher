package com.ilauncher.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/** Launcher icinde acilan tam ekran uygulamalarin ortak tabani (Ayarlar, Hesap Makinesi...). */
abstract class ScreenBase extends FrameLayout {

    interface Host {
        void closeScreen(ScreenBase s);

        void openInternal(int id, View from);

        boolean launchIntent(Intent i);

        int bottomInset();
    }

    protected final Host host;
    protected final float d;

    ScreenBase(Context c, Host h) {
        super(c);
        host = h;
        d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
    }

    protected int dp(float v) {
        return Math.round(v * d);
    }

    /** Durum cubugu yazilari koyu olsun mu (acik renkli ekranlar icin true). */
    abstract boolean darkStatus();

    /** Yari saydam katman mi (Kontrol Merkezi gibi); true ise ana ekran arkada kalir. */
    boolean translucent() {
        return false;
    }

    /** Geri tusu: ekran kendi icinde bir sey yaptiysa true dondurur. */
    boolean onBack() {
        return false;
    }

    /** Kapanmadan hemen once cagrilir (kaydetmek icin). */
    void onClosing() {
    }

    /** Alta iPhone'daki gibi ana ekran cubugu ekler; yukari cekince ekran kapanir. */
    protected void addHomeBar(final boolean lightBar) {
        final int h = dp(34) + host.bottomInset();
        final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setColor(lightBar ? 0xCCFFFFFF : 0xCC000000);
        final RectF r = new RectF();

        View strip = new View(getContext()) {
            @Override
            protected void onDraw(Canvas c) {
                float w = dp(134);
                float bh = dp(5);
                float cx = getWidth() / 2f;
                float cy = getHeight() - host.bottomInset() - dp(10);
                r.set(cx - w / 2f, cy - bh / 2f, cx + w / 2f, cy + bh / 2f);
                c.drawRoundRect(r, bh / 2f, bh / 2f, barPaint);
            }
        };
        strip.setOnTouchListener(new View.OnTouchListener() {
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = Math.min(0f, e.getRawY() - downY);
                        float f = Math.min(1f, -dy / dp(420));
                        ScreenBase.this.setTranslationY(dy * 0.9f);
                        ScreenBase.this.setAlpha(1f - 0.4f * f);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (downY - e.getRawY() > dp(100)) {
                            host.closeScreen(ScreenBase.this);
                        } else {
                            ScreenBase.this.animate().translationY(0f).alpha(1f).setDuration(260).start();
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        addView(strip, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM));
    }
}
