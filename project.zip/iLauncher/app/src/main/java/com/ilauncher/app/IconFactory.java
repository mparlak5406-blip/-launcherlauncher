package com.ilauncher.app;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

/** Her uygulama ikonunu iPhone tarzi yuvarlatilmis kare (squircle) seklinde cizer. */
final class IconFactory {
    private static final int LIGHT = 0xFFF2F2F7;

    private IconFactory() {
    }

    static Bitmap squircle(Drawable d, int size) {
        Bitmap content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        drawContent(d, new Canvas(content), size);

        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas oc = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setShader(new BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        float r = size * 0.2237f;
        oc.drawRoundRect(new RectF(0, 0, size, size), r, r, p);

        // Cok ince kenar cizgisi: beyaz ikonlar duvar kagidinda net gorunsun.
        Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Math.max(1f, size / 110f));
        edge.setColor(0x24000000);
        float h = edge.getStrokeWidth() / 2f;
        oc.drawRoundRect(new RectF(h, h, size - h, size - h), r - h, r - h, edge);
        content.recycle();
        return out;
    }

    private static void drawContent(Drawable d, Canvas c, int size) {
        if (d instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable a = (AdaptiveIconDrawable) d;
            // Uyarlanabilir ikonlar 108dp katmandir, gorunen kisim ortadaki 72dp'dir.
            int full = Math.round(size * 108f / 72f);
            int off = (full - size) / 2;
            Bitmap big = Bitmap.createBitmap(full, full, Bitmap.Config.ARGB_8888);
            Canvas bc = new Canvas(big);
            Drawable bg = a.getBackground();
            Drawable fg = a.getForeground();
            if (bg != null) {
                bg.setBounds(0, 0, full, full);
                bg.draw(bc);
            } else {
                bc.drawColor(Color.WHITE);
            }
            if (fg != null) {
                fg.setBounds(0, 0, full, full);
                fg.draw(bc);
            }
            c.drawBitmap(big, -off, -off, null);
            big.recycle();
            return;
        }

        // Eski tip ikon: iki kat buyuklukte ciz, gorunen kismin sinirlarini bul.
        int n = size * 2;
        Bitmap raw = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, n, n);
        d.draw(new Canvas(raw));
        int[] px = new int[n * n];
        raw.getPixels(px, 0, n, 0, 0, n, n);

        int minX = n, minY = n, maxX = -1, maxY = -1;
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                if (Color.alpha(px[y * n + x]) > 24) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) {
            c.drawColor(LIGHT);
            raw.recycle();
            return;
        }

        int bw = maxX - minX + 1;
        int bh = maxY - minY + 1;
        int opaque = 0;
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                if (Color.alpha(px[y * n + x]) > 200) {
                    opaque++;
                }
            }
        }
        float cover = opaque / (float) (bw * bh);
        float aspect = Math.min(bw, bh) / (float) Math.max(bw, bh);
        Rect src = new Rect(minX, minY, maxX + 1, maxY + 1);
        Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

        if (aspect > 0.85f && cover > 0.80f) {
            // Zaten yuvarlak kare olan ikon: cerceveyi at, tum karoyu doldur.
            int edgeColor = px[((minY + maxY) / 2) * n + minX + Math.min(3, bw - 1)];
            c.drawColor(Color.alpha(edgeColor) > 200 ? (edgeColor | 0xFF000000) : LIGHT);
            c.drawBitmap(raw, src, new Rect(0, 0, size, size), bp);
        } else {
            // Yuvarlak veya sekil olarak duran ikon: acik zemine ortala.
            c.drawColor(LIGHT);
            float target = size * 0.74f;
            float sc = Math.min(target / bw, target / bh);
            float dw = bw * sc;
            float dh = bh * sc;
            c.drawBitmap(raw, src, new RectF((size - dw) / 2f, (size - dh) / 2f,
                    (size + dw) / 2f, (size + dh) / 2f), bp);
        }
        raw.recycle();
    }
}
