package com.ilauncher.app;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

/** Her uygulama ikonunu iPhone tarzi yuvarlatilmis kare (squircle) seklinde cizer. */
final class IconFactory {
    private IconFactory() {
    }

    static Bitmap squircle(Drawable d, int size) {
        Bitmap content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        drawContent(d, new Canvas(content), size);

        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setShader(new BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        float r = size * 0.2237f;
        new Canvas(out).drawRoundRect(new RectF(0, 0, size, size), r, r, p);
        return out;
    }

    private static void drawContent(Drawable d, Canvas c, int size) {
        if (d instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable a = (AdaptiveIconDrawable) d;
            // Uyarlanabilir ikonlar 108dp katmandir, gorunen kisim ortadaki 72dp'dir.
            int full = Math.round(size * 108f / 72f);
            int off = (full - size) / 2;
            Bitmap big = Bitmap.createBitmap(full, full, Bitmap.Config.ARGB_8888);
            Canvas bc = new Canvas(big);
            Drawable bg = a.getBackground();
            Drawable fg = a.getForeground();
            if (bg != null) {
                bg.setBounds(0, 0, full, full);
                bg.draw(bc);
            } else {
                bc.drawColor(Color.WHITE);
            }
            if (fg != null) {
                fg.setBounds(0, 0, full, full);
                fg.draw(bc);
            }
            c.drawBitmap(big, -off, -off, null);
            big.recycle();
            return;
        }

        Bitmap raw = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas rc = new Canvas(raw);
        d.setBounds(0, 0, size, size);
        d.draw(rc);
        boolean fullBleed = Color.alpha(raw.getPixel(1, 1)) >= 250
                && Color.alpha(raw.getPixel(size - 2, 1)) >= 250
                && Color.alpha(raw.getPixel(1, size - 2)) >= 250
                && Color.alpha(raw.getPixel(size - 2, size - 2)) >= 250;
        if (fullBleed) {
            c.drawBitmap(raw, 0, 0, null);
        } else {
            // Seffaf kenarli eski tip ikonlar: acik gri zemin uzerine biraz kucultup yerlestir.
            c.drawColor(Color.parseColor("#F2F2F7"));
            int inset = Math.round(size * 0.14f);
            c.drawBitmap(raw, null, new Rect(inset, inset, size - inset, size - inset),
                    new Paint(Paint.FILTER_BITMAP_FLAG));
        }
        raw.recycle();
    }
}
