package com.ilauncher.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** iPhone tarzi durum cubugu: solda saat, sagda pil. */
final class StatusBarView extends View {
    private final float d;
    private final Paint timePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pctPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint batPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String time = "";
    private int level = 100;
    private boolean charging;

    StatusBarView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;

        timePaint.setColor(Color.WHITE);
        timePaint.setTextSize(16f * d);
        timePaint.setTypeface(Typeface.DEFAULT_BOLD);
        timePaint.setTextAlign(Paint.Align.LEFT);

        pctPaint.setColor(Color.WHITE);
        pctPaint.setTextSize(13f * d);
        pctPaint.setTypeface(Typeface.DEFAULT_BOLD);
        pctPaint.setTextAlign(Paint.Align.RIGHT);
    }

    void setTime(String t) {
        time = t;
        invalidate();
    }

    void setBattery(int pct, boolean isCharging) {
        level = Math.max(0, Math.min(100, pct));
        charging = isCharging;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        // Dynamic Island 10dp'den baslar ve 30dp yuksekliktedir; ortasi 25dp.
        float cy = 25f * d;

        Paint.FontMetrics fm = timePaint.getFontMetrics();
        c.drawText(time, 30f * d, cy - (fm.ascent + fm.descent) / 2f, timePaint);

        float right = getWidth() - 22f * d;
        float bw = 25f * d;
        float bh = 12f * d;
        float r = 3.5f * d;
        float left = right - bw - 2.5f * d;

        batPaint.setStyle(Paint.Style.STROKE);
        batPaint.setStrokeWidth(d);
        batPaint.setColor(0x88FFFFFF);
        c.drawRoundRect(new RectF(left, cy - bh / 2, left + bw, cy + bh / 2), r, r, batPaint);

        batPaint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(left + bw + d, cy - 2f * d, left + bw + 2.5f * d, cy + 2f * d), d, d, batPaint);

        float pad = 1.8f * d;
        float fillW = (bw - 2 * pad) * Math.max(0.06f, level / 100f);
        if (charging) {
            batPaint.setColor(0xFF30D158);
        } else if (level <= 20) {
            batPaint.setColor(0xFFFF453A);
        } else {
            batPaint.setColor(Color.WHITE);
        }
        c.drawRoundRect(new RectF(left + pad, cy - bh / 2 + pad, left + pad + fillW, cy + bh / 2 - pad),
                r - pad, r - pad, batPaint);

        Paint.FontMetrics pm = pctPaint.getFontMetrics();
        c.drawText(level + "%", left - 7f * d, cy - (pm.ascent + pm.descent) / 2f, pctPaint);
    }
}
