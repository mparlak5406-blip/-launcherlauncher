package com.ilauncher.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** iPhone tarzi durum cubugu: solda saat, sagda sebeke, Wi-Fi ve ici sayili pil. */
final class StatusBarView extends View {
    private final float d;
    private final Paint timePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pctPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path bolt = new Path();

    private String time = "";
    private int level = 100;
    private boolean charging;
    private int wifi = -1;   // -1: bagli degil, 0..3: sinyal seviyesi
    private int cell = -1;   // -1: SIM yok, 0..4: sinyal seviyesi
    private int ink = Color.WHITE;

    StatusBarView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;

        timePaint.setColor(ink);
        timePaint.setTextSize(17f * d);
        timePaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        timePaint.setTextAlign(Paint.Align.LEFT);

        pctPaint.setColor(0xFF111111);
        pctPaint.setTextSize(9.5f * d);
        pctPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        pctPaint.setTextAlign(Paint.Align.CENTER);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(2f * d);
    }

    /** Acik renkli ekranlarda (Ayarlar gibi) yazilar koyu olsun. */
    void setDark(boolean dark) {
        ink = dark ? 0xFF111111 : Color.WHITE;
        timePaint.setColor(ink);
        pctPaint.setColor(dark ? Color.WHITE : 0xFF111111);
        invalidate();
    }

    void setTime(String t) {
        time = t;
        invalidate();
    }

    void setBattery(int pct, boolean isCharging) {
        level = Math.max(0, Math.min(100, pct));
        charging = isCharging;
        invalidate();
    }

    void setNetwork(int wifiLevel, int cellLevel) {
        wifi = wifiLevel;
        cell = cellLevel;
        invalidate();
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        // Dynamic Island 10dp'den baslar ve 30dp yuksekliktedir; ortasi 25dp.
        float cy = 25f * d;

        Paint.FontMetrics fm = timePaint.getFontMetrics();
        c.drawText(time, 32f * d, cy - (fm.ascent + fm.descent) / 2f, timePaint);

        // ---- pil
        float right = getWidth() - 20f * d;
        float bw = 27f * d;
        float bh = 13f * d;
        float bl = right - bw - 2.4f * d;
        float bt = cy - bh / 2f;

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(withAlpha(ink, 0x66));
        rect.set(bl, bt, bl + bw, bt + bh);
        c.drawRoundRect(rect, 4.2f * d, 4.2f * d, fill);

        float in = 1.6f * d;
        float fw = (bw - 2 * in) * Math.max(0.08f, level / 100f);
        if (charging) {
            fill.setColor(0xFF30D158);
        } else if (level <= 20) {
            fill.setColor(0xFFFF453A);
        } else {
            fill.setColor(ink);
        }
        rect.set(bl + in, bt + in, bl + in + fw, bt + bh - in);
        c.drawRoundRect(rect, 3f * d, 3f * d, fill);

        fill.setColor(withAlpha(ink, 0x99));
        rect.set(bl + bw + 0.8f * d, cy - 2.2f * d, bl + bw + 2.4f * d, cy + 2.2f * d);
        c.drawRoundRect(rect, d, d, fill);

        Paint.FontMetrics pm = pctPaint.getFontMetrics();
        c.drawText(String.valueOf(level), bl + bw / 2f, cy - (pm.ascent + pm.descent) / 2f, pctPaint);

        float x = bl - 7f * d;

        // ---- sarj simgesi
        if (charging) {
            float bx = bl - 7f * d;
            bolt.reset();
            bolt.moveTo(bx + 1.6f * d, cy - 6f * d);
            bolt.lineTo(bx - 2.6f * d, cy + 0.8f * d);
            bolt.lineTo(bx - 0.2f * d, cy + 0.8f * d);
            bolt.lineTo(bx - 1.6f * d, cy + 6f * d);
            bolt.lineTo(bx + 2.6f * d, cy - 1f * d);
            bolt.lineTo(bx + 0.2f * d, cy - 1f * d);
            bolt.close();
            fill.setColor(0xFF30D158);
            c.drawPath(bolt, fill);
            x = bl - 14f * d;
        }

        // ---- Wi-Fi
        if (wifi >= 0) {
            float wc = x - 9f * d;
            drawWifi(c, wc, cy);
            x = wc - 9f * d - 5f * d;
        }

        // ---- hucresel sebeke cubuklari
        if (cell >= 0) {
            float cw = 4 * 3f * d + 3 * 1.6f * d;
            drawBars(c, x - cw, cy);
        }
    }

    private void drawWifi(Canvas c, float cx, float cy) {
        float by = cy + 6f * d;
        int lit = Math.max(1, wifi);
        float[] radii = {4.5f * d, 8.4f * d, 12.3f * d};
        for (int i = 0; i < 3; i++) {
            arc.setColor(i < lit ? ink : withAlpha(ink, 0x66));
            float r = radii[i];
            rect.set(cx - r, by - r, cx + r, by + r);
            c.drawArc(rect, 225f, 90f, false, arc);
        }
        fill.setColor(ink);
        c.drawCircle(cx, by - 0.4f * d, 1.5f * d, fill);
    }

    private void drawBars(Canvas c, float left, float cy) {
        float base = cy + 6f * d;
        float[] heights = {4.5f * d, 7.2f * d, 9.8f * d, 12.4f * d};
        for (int i = 0; i < 4; i++) {
            fill.setColor(i < cell ? ink : withAlpha(ink, 0x66));
            float l = left + i * (3f * d + 1.6f * d);
            rect.set(l, base - heights[i], l + 3f * d, base);
            c.drawRoundRect(rect, 1f * d, 1f * d, fill);
        }
    }
}
