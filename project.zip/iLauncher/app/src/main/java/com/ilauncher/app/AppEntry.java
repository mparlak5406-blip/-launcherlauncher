package com.ilauncher.app;

import android.content.Intent;
import android.graphics.Bitmap;

/** Yuklu bir uygulamanin ana ekranda gosterilen bilgileri. */
final class AppEntry {
    final String label;
    final String pkg;
    final Intent launch;
    final int category;
    final long installTime;
    final Bitmap icon;

    AppEntry(String label, String pkg, Intent launch, int category, long installTime, Bitmap icon) {
        this.label = label;
        this.pkg = pkg;
        this.launch = launch;
        this.category = category;
        this.installTime = installTime;
        this.icon = icon;
    }
}
