package com.ilauncher.app;

import android.content.Intent;
import android.graphics.Bitmap;

/** Yuklu bir uygulamanin ana ekranda gosterilen bilgileri. */
final class AppEntry {
    final String label;
    final String pkg;
    final Intent launch;
    final int category;
    final long installTime;
    final Bitmap icon;
    /** 0: normal uygulama; 1: Ayarlar, 2: Hesap Makinesi, 3: Notlar (launcher'in kendi uygulamalari). */
    final int internalId;

    AppEntry(String label, String pkg, Intent launch, int category, long installTime, Bitmap icon) {
        this(label, pkg, launch, category, installTime, icon, 0);
    }

    AppEntry(String label, String pkg, Intent launch, int category, long installTime, Bitmap icon, int internalId) {
        this.label = label;
        this.pkg = pkg;
        this.launch = launch;
        this.category = category;
        this.installTime = installTime;
        this.icon = icon;
        this.internalId = internalId;
    }
}
