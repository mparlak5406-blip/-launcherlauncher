package com.ilauncher.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Koddan cizilen, iPhone tarzi renkli geciş (mesh) duvar kagidi. */
final class WallpaperView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    WallpaperView(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        paint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF1B1464, 0xFF5B2A86, 0xFF1A1240},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);

        blob(canvas, w * 0.15f, h * 0.18f, w * 0.95f, 0xFFFF5F6D, 0.75f);
        blob(canvas, w * 0.90f, h * 0.50f, w * 1.00f, 0xFF00C6FF, 0.60f);
        blob(canvas, w * 0.25f, h * 0.95f, w * 1.00f, 0xFFFFB75E, 0.70f);
    }

    private void blob(Canvas canvas, float x, float y, float radius, int color, float alpha) {
        int rgb = color & 0x00FFFFFF;
        int center = rgb | (Math.round(255 * alpha) << 24);
        paint.setShader(new RadialGradient(x, y, radius, center, rgb, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
    }
}
