package com.ilauncher.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** iPhone tarzi Ayarlar ekrani. Satirlar sistemin gercek ayar sayfalarini acar. */
final class SettingsScreen extends ScreenBase {
    private static final int BG = 0xFFF2F2F7;
    private static final int BLUE = 0xFF0A84FF;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final class Row {
        final String label;
        final int glyph;
        final int color;
        final boolean about;
        final String[] actions;

        Row(String label, int glyph, int color, boolean about, String... actions) {
            this.label = label;
            this.glyph = glyph;
            this.color = color;
            this.about = about;
            this.actions = actions;
        }
    }

    private final List<List<Row>> groups = new ArrayList<>();
    private final ScrollView scroll;
    private final ScrollView aboutScroll;
    private final LinearLayout body;
    private boolean inAbout;

    SettingsScreen(Context c, Host h) {
        super(c, h);
        setBackgroundColor(BG);
        buildGroups();

        int pad = dp(16);
        int bottomPad = dp(34) + host.bottomInset() + dp(16);

        // ---- ana liste
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, dp(56), pad, bottomPad);
        scroll.addView(content, new FrameLayout.LayoutParams(MATCH, WRAP));

        TextView title = text(c, "Ayarlar", 34f, 0xFF000000, true);
        title.setPadding(dp(4), 0, 0, dp(10));
        content.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        EditText search = new EditText(c);
        search.setHint("Ara");
        search.setHintTextColor(0xFF8E8E93);
        search.setTextColor(0xFF000000);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        search.setSingleLine(true);
        search.setPadding(dp(14), dp(9), dp(14), dp(9));
        GradientDrawable sb = new GradientDrawable();
        sb.setColor(0x1F767680);
        sb.setCornerRadius(dp(11));
        search.setBackground(sb);
        content.addView(search, new LinearLayout.LayoutParams(MATCH, WRAP));

        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(MATCH, WRAP);
        bp.topMargin = dp(14);
        content.addView(body, bp);
        render("");

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int n) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int n) {
                render(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        addView(scroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- Hakkinda sayfasi
        aboutScroll = new ScrollView(c);
        aboutScroll.setVerticalScrollBarEnabled(false);
        aboutScroll.setBackgroundColor(BG);
        aboutScroll.setVisibility(View.GONE);
        LinearLayout about = new LinearLayout(c);
        about.setOrientation(LinearLayout.VERTICAL);
        about.setPadding(pad, dp(52), pad, bottomPad);
        aboutScroll.addView(about, new FrameLayout.LayoutParams(MATCH, WRAP));

        TextView back = text(c, "‹ Ayarlar", 17f, BLUE, false);
        back.setPadding(dp(4), dp(4), dp(12), dp(10));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideAbout();
            }
        });
        about.addView(back, new LinearLayout.LayoutParams(WRAP, WRAP));
        TextView t2 = text(c, "Hakkında", 34f, 0xFF000000, true);
        t2.setPadding(dp(4), 0, 0, dp(14));
        about.addView(t2, new LinearLayout.LayoutParams(MATCH, WRAP));
        about.addView(aboutCard(c), new LinearLayout.LayoutParams(MATCH, WRAP));
        addView(aboutScroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        addHomeBar(false);
    }

    @Override
    boolean darkStatus() {
        return true;
    }

    @Override
    boolean onBack() {
        if (inAbout) {
            hideAbout();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ veri

    private void buildGroups() {
        List<Row> g1 = new ArrayList<>();
        g1.add(new Row("Uçak Modu", Glyph.PLANE, 0xFFFF9F0A, false, Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        g1.add(new Row("Wi-Fi", Glyph.WIFI, BLUE, false, Settings.ACTION_WIFI_SETTINGS));
        g1.add(new Row("Bluetooth", Glyph.BT, BLUE, false, Settings.ACTION_BLUETOOTH_SETTINGS));
        g1.add(new Row("Mobil Veri", Glyph.DATA, 0xFF30D158, false,
                Settings.ACTION_DATA_ROAMING_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS));
        groups.add(g1);

        List<Row> g2 = new ArrayList<>();
        g2.add(new Row("Bildirimler", Glyph.BELL, 0xFFFF3B30, false,
                Settings.ACTION_APP_NOTIFICATION_SETTINGS, Settings.ACTION_SETTINGS));
        g2.add(new Row("Ses ve Titreşim", Glyph.SOUND, 0xFFFF2D55, false, Settings.ACTION_SOUND_SETTINGS));
        g2.add(new Row("Ekran ve Parlaklık", Glyph.SUN, BLUE, false, Settings.ACTION_DISPLAY_SETTINGS));
        g2.add(new Row("Pil", Glyph.BATTERY, 0xFF30D158, false,
                Intent.ACTION_POWER_USAGE_SUMMARY, Settings.ACTION_BATTERY_SAVER_SETTINGS));
        groups.add(g2);

        List<Row> g3 = new ArrayList<>();
        g3.add(new Row("Depolama", Glyph.STORAGE, 0xFF8E8E93, false, Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        g3.add(new Row("Uygulamalar", Glyph.APPS, BLUE, false, Settings.ACTION_APPLICATION_SETTINGS));
        g3.add(new Row("Konum", Glyph.HAND, BLUE, false, Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        g3.add(new Row("Gizlilik ve Güvenlik", Glyph.LOCK, 0xFF8E8E93, false, Settings.ACTION_SECURITY_SETTINGS));
        groups.add(g3);

        List<Row> g4 = new ArrayList<>();
        g4.add(new Row("Dil ve Bölge", Glyph.GLOBE, BLUE, false, Settings.ACTION_LOCALE_SETTINGS));
        g4.add(new Row("Tarih ve Saat", Glyph.CLOCK, 0xFF8E8E93, false, Settings.ACTION_DATE_SETTINGS));
        g4.add(new Row("Erişilebilirlik", Glyph.HAND, BLUE, false, Settings.ACTION_ACCESSIBILITY_SETTINGS));
        g4.add(new Row("Varsayılan Ana Ekran", Glyph.HOME, 0xFF8E8E93, false, Settings.ACTION_HOME_SETTINGS));
        groups.add(g4);

        List<Row> g5 = new ArrayList<>();
        g5.add(new Row("Telefon Hakkında", Glyph.INFO, 0xFF8E8E93, true));
        g5.add(new Row("Tüm Sistem Ayarları", Glyph.GEAR, 0xFF8E8E93, false, Settings.ACTION_SETTINGS));
        groups.add(g5);
    }

    // ------------------------------------------------------------------ gorunum

    private TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private LinearLayout card(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        card.setClipToOutline(true);
        card.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        return card;
    }

    private void render(String filter) {
        Context c = getContext();
        body.removeAllViews();
        String f = filter.trim().toLowerCase(new Locale("tr", "TR"));

        if (f.isEmpty()) {
            body.addView(profileCard(c), cardParams());
            for (List<Row> g : groups) {
                LinearLayout card = card(c);
                for (int i = 0; i < g.size(); i++) {
                    addRow(card, g.get(i), i == g.size() - 1);
                }
                body.addView(card, cardParams());
            }
            return;
        }

        List<Row> hits = new ArrayList<>();
        for (List<Row> g : groups) {
            for (Row r : g) {
                if (r.label.toLowerCase(new Locale("tr", "TR")).contains(f)) {
                    hits.add(r);
                }
            }
        }
        if (hits.isEmpty()) {
            TextView none = text(c, "Sonuç yok", 17f, 0xFF8E8E93, false);
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, dp(40), 0, 0);
            body.addView(none, new LinearLayout.LayoutParams(MATCH, WRAP));
            return;
        }
        LinearLayout card = card(c);
        for (int i = 0; i < hits.size(); i++) {
            addRow(card, hits.get(i), i == hits.size() - 1);
        }
        body.addView(card, cardParams());
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(20);
        return lp;
    }

    private void addRow(LinearLayout card, final Row r, boolean last) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), 0, dp(12), 0);

        ImageView icon = new ImageView(c);
        icon.setImageBitmap(Glyph.tile(r.glyph, r.color, dp(30)));
        row.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView label = text(c, r.label, 17f, 0xFF000000, false);
        label.setSingleLine(true);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ll.leftMargin = dp(14);
        row.addView(label, ll);

        row.addView(text(c, "›", 26f, 0xFFC7C7CC, false), new LinearLayout.LayoutParams(WRAP, WRAP));

        row.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setBackgroundColor(0xFFD1D1D6);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setBackgroundColor(Color.TRANSPARENT);
                }
                return false;
            }
        });
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(r);
            }
        });
        card.addView(row, new LinearLayout.LayoutParams(MATCH, dp(48)));

        if (!last) {
            View line = new View(c);
            line.setBackgroundColor(0xFFE5E5EA);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, 1);
            lp.leftMargin = dp(60);
            card.addView(line, lp);
        }
    }

    private View profileCard(Context c) {
        LinearLayout card = card(c);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        String name = deviceName();
        ImageView av = new ImageView(c);
        av.setImageBitmap(avatar(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(), dp(56)));
        card.addView(av, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c, name, 20f, 0xFF000000, true), new LinearLayout.LayoutParams(WRAP, WRAP));
        col.addView(text(c, "Android " + Build.VERSION.RELEASE + " · " + Build.MODEL, 13f, 0xFF8E8E93, false),
                new LinearLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        cl.leftMargin = dp(14);
        card.addView(col, cl);
        return card;
    }

    private Bitmap avatar(String letter, int px) {
        Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, px, px, 0xFF5E5CE6, 0xFFFF6A3D, Shader.TileMode.CLAMP));
        cv.drawCircle(px / 2f, px / 2f, px / 2f, p);
        p.setShader(null);
        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(px * 0.46f);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        Paint.FontMetrics fm = p.getFontMetrics();
        cv.drawText(letter, px / 2f, px / 2f - (fm.ascent + fm.descent) / 2f, p);
        return b;
    }

    private String deviceName() {
        String n = null;
        try {
            n = Settings.Global.getString(getContext().getContentResolver(), "device_name");
        } catch (Throwable ignored) {
        }
        if (n == null || n.trim().isEmpty()) {
            n = Build.MODEL;
        }
        return n;
    }

    // ------------------------------------------------------------------ islemler

    private void open(Row r) {
        if (r.about) {
            showAbout();
            return;
        }
        for (String a : r.actions) {
            Intent i = new Intent(a);
            if (Settings.ACTION_APP_NOTIFICATION_SETTINGS.equals(a)) {
                i.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            }
            if (host.launchIntent(i)) {
                return;
            }
        }
        Toast.makeText(getContext(), "Bu ayar açılamadı", Toast.LENGTH_SHORT).show();
    }

    private void showAbout() {
        inAbout = true;
        aboutScroll.setAlpha(0f);
        aboutScroll.setTranslationX(dp(40));
        aboutScroll.setVisibility(View.VISIBLE);
        aboutScroll.animate().alpha(1f).translationX(0f).setDuration(260).start();
        scroll.animate().alpha(0f).setDuration(200).start();
    }

    private void hideAbout() {
        inAbout = false;
        scroll.animate().alpha(1f).setDuration(240).start();
        aboutScroll.animate().alpha(0f).translationX(dp(40)).setDuration(220).withEndAction(new Runnable() {
            @Override
            public void run() {
                aboutScroll.setVisibility(View.GONE);
            }
        }).start();
    }

    private View aboutCard(Context c) {
        LinearLayout card = card(c);
        List<String[]> kv = new ArrayList<>();
        kv.add(new String[]{"Cihaz Adı", deviceName()});
        kv.add(new String[]{"Model", Build.MANUFACTURER + " " + Build.MODEL});
        kv.add(new String[]{"Android Sürümü", Build.VERSION.RELEASE});
        kv.add(new String[]{"Güvenlik Yaması", Build.VERSION.SECURITY_PATCH});
        kv.add(new String[]{"Yazılım Sürümü", Build.DISPLAY});
        kv.add(new String[]{"İşlemci Mimarisi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "-"});
        kv.add(new String[]{"Bellek (RAM)", ramText(c)});
        kv.add(new String[]{"Depolama", storageText()});
        for (int i = 0; i < kv.size(); i++) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(12), dp(16), dp(12));
            TextView k = text(c, kv.get(i)[0], 17f, 0xFF000000, false);
            row.addView(k, new LinearLayout.LayoutParams(WRAP, WRAP));
            TextView v = text(c, kv.get(i)[1], 17f, 0xFF8E8E93, false);
            v.setGravity(Gravity.END);
            LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(0, WRAP, 1f);
            vl.leftMargin = dp(16);
            row.addView(v, vl);
            card.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
            if (i < kv.size() - 1) {
                View line = new View(c);
                line.setBackgroundColor(0xFFE5E5EA);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, 1);
                lp.leftMargin = dp(16);
                card.addView(line, lp);
            }
        }
        return card;
    }

    private String ramText(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return String.format(Locale.US, "%.1f GB", mi.totalMem / 1073741824.0);
        } catch (Throwable t) {
            return "-";
        }
    }

    private String storageText() {
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            double total = fs.getTotalBytes() / 1073741824.0;
            double free = fs.getAvailableBytes() / 1073741824.0;
            return String.format(Locale.US, "%.1f GB boş / %.0f GB", free, total);
        } catch (Throwable t) {
            return "-";
        }
    }
}
