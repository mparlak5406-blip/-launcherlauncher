# iLauncher: iPhone tarzı ana ekran (Redmi Note 9 Pro)

Bu bir Android ana ekran (launcher) uygulamasıdır. Telefonun Android sürümünü değiştirmez; ana ekranı, uygulama ikonlarını, dock'u, durum çubuğunu ve Dynamic Island benzeri hapı iPhone tarzına çevirir.

> Önemli: Kodu bu ortamda derleyemedim (Android araçlarına erişim yok), bu yüzden henüz hiçbir telefonda denenmedi. Aşağıdaki bulut derlemesi hata verirse hata mesajını bana gönderin, düzeltirim.

## APK'yı telefondan derletme (bilgisayar gerekmez)

Tarayıcıda "Masaüstü sitesi" seçeneğini açarsanız GitHub'ı kullanmak kolaylaşır.

1. github.com'da ücretsiz hesap açın, **New repository** ile `ilauncher` adında bir repo oluşturun.
2. Repoda **Add file > Create new file** deyin. Dosya adı kutusuna tam olarak `.github/workflows/build.yml` yazın. `build.yml` dosyasının içeriğini yapıştırıp **Commit changes** deyin.
3. **Add file > Upload files** ile `project.zip` dosyasını (açmadan) yükleyip **Commit changes** deyin.
4. **Actions** sekmesinde "APK derle" çalışır. 3-6 dakika sonra yeşil tik çıkar.
5. Repo ana sayfasında sağdaki **Releases** bölümünden en üstteki sürüme girin ve `iLauncher.apk` dosyasını indirin.

## Telefona kurma

1. İndirilen `iLauncher.apk` dosyasına dokunun, istenirse "bu kaynaktan yüklemeye izin ver" deyin. Play Protect uyarırsa "Yine de yükle" seçin.
2. **Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması** (MIUI'de menü adı biraz değişebilir) yolundan **iLauncher**'ı seçin. Ana ekran tuşuna basınca da seçim sorabilir.
3. Eski haline dönmek için aynı yerden sistem ana ekranını (Sistem başlatıcısı) seçin.

## Sürüm 1.1 yenilikleri

- İkonlar gri çerçeveden kurtuldu, tüm kareyi dolduruyor.
- Durum çubuğunda saat, hücresel sinyal, Wi-Fi ve içi sayılı pil var. Şarj takılınca hap kendiliğinden açılır.
- Sayfa geçişleri derinlik efektli, ikonlar basınca yaylanıyor, uygulamalar ikondan büyüyerek açılıyor.
- Uzun basınca iPhone tarzı menü ve titreme (düzenleme) modu. Sol üstten aşağı çekince bildirimler, sağ üstten çekince kontrol merkezi.

## Kullanım

- Sağa/sola kaydırın: sayfalar. Son sayfa **Uygulama Kitaplığı** (kategorilere göre gruplar).
- Ana ekranda aşağı çekin: **arama**.
- Bir uygulamaya uzun basın: Uygulama bilgisi / Kaldır.
- Üstteki siyah hapa dokunun: pil bilgisi açılır.
- Dock'ta telefon, mesaj, tarayıcı ve kamera uygulamalarınız (bulunamazsa ilk uygulamalar) yer alır.

## Bilmeniz gerekenler

- Sistem durum çubuğu gizlenir, yerine saat ve pil gösteren kendi çubuğumuz çıkar. Bildirim simgeleri ve şebeke göstergesi görünmez. Ekranın üstünden aşağı çekince bildirim paneli yine açılır.
- Hapın konumu telefonun ön kamera deliğine göre ayarlıdır. Kayık duruyorsa `IslandView.java` içindeki `TOP_DP` ve `StatusBarView.java` içindeki `cy` değerini değiştirin.
- Ana ekran tuşu/jest davranışı MIUI'nin kendi ayarlarına bağlıdır. Bazen "Son kullanılanlar" ekranı sistemin eski görünümüyle gelir.
- APK, projedeki `ilauncher.jks` anahtarıyla imzalanır; böylece sonraki sürümleri üzerine kurabilirsiniz. Kişisel kullanım içindir.

## Bilgisayarınız varsa

`project.zip` içindeki `iLauncher` klasörünü Android Studio ile açıp **Build > Build APK(s)** diyebilirsiniz (Android SDK 34 gerekir).
