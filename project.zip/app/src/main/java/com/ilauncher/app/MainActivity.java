package com.ilauncher.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** iPhone tarzi ana ekran (launcher). */
public class MainActivity extends Activity implements ScreenBase.Host {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int COLS = 4;
    private static final int ICON_DP = 60;
    private static final int TOP_DP = 58;       // sayfalarin ustundeki bosluk (durum cubugu + ada)
    private static final int DOCK_DP = 92;      // dock yuksekligi
    private static final int DOCK_GAP_DP = 12;  // dock'un alt kenardan uzakligi

    private final List<AppEntry> all = new ArrayList<>();
    private final List<AppEntry> dockApps = new ArrayList<>();
    private final Locale tr = new Locale("tr", "TR");

    private float density;
    private int bottomInset;
    private int rootW;
    private int rootH;
    private boolean loaded;
    private boolean introPlayed;
    private int cellLevel = -1;
    private TelephonyManager telephony;
    private PhoneStateListener cellListener;

    private FrameLayout root;
    private PagerLayout pager;
    private LinearLayout dots;
    private LinearLayout dock;
    private StatusBarView statusBar;
    private IslandView island;
    private FrameLayout searchOverlay;
    private EditText searchBox;
    private LinearLayout searchResults;

    // ------------------------------------------------------------------ yasam dongusu

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;

        Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(lp);
        }
        win.setNavigationBarColor(Color.TRANSPARENT);

        buildUi();
        setContentView(root);
        applySystemUi();
        root.requestApplyInsets();

        registerReceivers();
        startCellListener();
        updateTime();
        updateNetwork();
        loadAppsAsync();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applySystemUi();
        updateTime();
        updateNetwork();
        PillService.start(this);
        PillService.suppress(true);
        askOverlayOnce();
        if (returning) {
            returning = false;
            playReturn();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        PillService.suppress(false);
    }

    private void askOverlayOnce() {
        try {
            if (android.provider.Settings.canDrawOverlays(this)) {
                return;
            }
            android.content.SharedPreferences sp = getSharedPreferences("ilauncher_prefs", MODE_PRIVATE);
            if (sp.getBoolean("overlay_asked", false)) {
                return;
            }
            sp.edit().putBoolean("overlay_asked", true).apply();
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName())));
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applySystemUi();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Ana ekran tusuna basilinca ilk sayfaya don.
        if (screen != null) {
            closeScreen(screen);
        }
        dismissMenu(false);
        if (editMode) {
            exitEditMode();
        }
        if (searchOverlay.getVisibility() == View.VISIBLE) {
            closeSearch();
        }
        pager.setPage(0, true);
    }

    @Override
    public void onBackPressed() {
        if (menuLayer != null) {
            dismissMenu(true);
        } else if (screen != null) {
            if (!screen.onBack()) {
                closeScreen(screen);
            }
        } else if (editMode) {
            exitEditMode();
        } else if (searchOverlay.getVisibility() == View.VISIBLE) {
            closeSearch();
        } else if (pager.getPage() != 0) {
            pager.setPage(0, true);
        }
        // Ana ekranda geri tusu bir sey yapmaz.
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }
        try {
            if (telephony != null && cellListener != null) {
                telephony.listen(cellListener, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Throwable ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi() {
        root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    // ------------------------------------------------------------------ arayuz kurulumu

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable roundedBg(int color, int radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        g.setStroke(Math.max(1, dp(0.5f)), 0x26FFFFFF);
        return g;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.addView(new WallpaperView(this), new FrameLayout.LayoutParams(MATCH, MATCH));

        pager = new PagerLayout(this);
        pager.setListener(new PagerLayout.Listener() {
            @Override
            public void onPageSelected(int index) {
                updateDots(index);
            }

            @Override
            public void onPullDown() {
                openSearch();
            }
        });
        root.addView(pager, new FrameLayout.LayoutParams(MATCH, MATCH));

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        root.addView(dots, new FrameLayout.LayoutParams(MATCH, dp(22), Gravity.BOTTOM));

        dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setBackground(roundedBg(0x40FFFFFF, dp(32)));
        root.addView(dock, new FrameLayout.LayoutParams(MATCH, dp(DOCK_DP), Gravity.BOTTOM));

        statusBar = new StatusBarView(this);
        root.addView(statusBar, new FrameLayout.LayoutParams(MATCH, dp(52), Gravity.TOP));
        statusBar.setOnTouchListener(new View.OnTouchListener() {
            private float sx;
            private float sy;

            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = ev.getX();
                        sy = ev.getY();
                        break;
                    case MotionEvent.ACTION_UP:
                        // Sol ustten cekince bildirimler, sag ustten cekince kontrol merkezi.
                        if (ev.getY() - sy > dp(36) && Math.abs(ev.getX() - sx) < dp(70)) {
                            openPanel(sx > v.getWidth() / 2f);
                        }
                        break;
                    default:
                        break;
                }
                return true;
            }
        });

        island = new IslandView(this);
        root.addView(island, new FrameLayout.LayoutParams(dp(230), dp(60), Gravity.TOP | Gravity.CENTER_HORIZONTAL));

        doneBtn = new TextView(this);
        doneBtn.setText("Bitti");
        doneBtn.setTextColor(Color.WHITE);
        doneBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        doneBtn.setTypeface(Typeface.DEFAULT_BOLD);
        doneBtn.setGravity(Gravity.CENTER);
        doneBtn.setPadding(dp(16), 0, dp(16), 0);
        doneBtn.setBackground(roundedBg(0x59FFFFFF, dp(15)));
        doneBtn.setVisibility(View.GONE);
        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitEditMode();
            }
        });
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(WRAP, dp(30), Gravity.TOP | Gravity.RIGHT);
        dlp.topMargin = dp(40);
        dlp.rightMargin = dp(16);
        root.addView(doneBtn, dlp);

        buildSearch();
        root.addView(searchOverlay, new FrameLayout.LayoutParams(MATCH, MATCH));
        searchOverlay.setVisibility(View.GONE);

        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                int w = r - l;
                int h = b - t;
                if (w != rootW || h != rootH) {
                    rootW = w;
                    rootH = h;
                    root.post(new Runnable() {
                        @Override
                        public void run() {
                            relayout();
                        }
                    });
                }
            }
        });

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            @SuppressWarnings("deprecation")
            public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                int bottom = insets.getSystemWindowInsetBottom();
                if (bottom != bottomInset) {
                    bottomInset = bottom;
                    relayout();
                }
                return insets;
            }
        });
    }

    private int pagerBottomMargin() {
        return dp(DOCK_GAP_DP) + bottomInset + dp(DOCK_DP) + dp(8) + dp(22) + dp(4);
    }

    private void relayout() {
        if (rootW == 0) {
            return;
        }
        FrameLayout.LayoutParams dl = (FrameLayout.LayoutParams) dock.getLayoutParams();
        dl.setMargins(dp(14), 0, dp(14), dp(DOCK_GAP_DP) + bottomInset);
        dock.setLayoutParams(dl);

        FrameLayout.LayoutParams dotsLp = (FrameLayout.LayoutParams) dots.getLayoutParams();
        dotsLp.bottomMargin = dp(DOCK_GAP_DP) + bottomInset + dp(DOCK_DP) + dp(8);
        dots.setLayoutParams(dotsLp);

        FrameLayout.LayoutParams pl = (FrameLayout.LayoutParams) pager.getLayoutParams();
        pl.topMargin = dp(TOP_DP);
        pl.bottomMargin = pagerBottomMargin();
        pager.setLayoutParams(pl);

        rebuildPages();
    }

    // ------------------------------------------------------------------ sayfalar

    private final View.OnTouchListener press = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().setStartDelay(0).scaleX(0.88f).scaleY(0.88f).setDuration(110)
                            .setInterpolator(new PathInterpolator(0.2f, 0f, 0f, 1f)).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(300)
                            .setInterpolator(new OvershootInterpolator(2.8f)).start();
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    private void rebuildPages() {
        if (!loaded || rootW == 0) {
            return;
        }
        stopWiggle();
        editMode = false;
        doneBtn.setVisibility(View.GONE);
        int pw = rootW;
        int ph = rootH - dp(TOP_DP) - pagerBottomMargin();
        int keep = pager.getPage();

        pager.removeAllViews();

        int rowH = dp(100);
        int rows = Math.max(3, (ph - dp(6)) / rowH);
        int perPage = COLS * rows;

        List<AppEntry> grid = new ArrayList<>(all);
        grid.removeAll(dockApps);
        int pages = Math.max(1, (grid.size() + perPage - 1) / perPage);
        for (int p = 0; p < pages; p++) {
            int from = Math.min(grid.size(), p * perPage);
            int to = Math.min(grid.size(), from + perPage);
            pager.addView(buildGridPage(grid.subList(from, to), rows, rowH));
        }
        pager.addView(buildLibraryPage(pw, ph));

        rebuildDock();

        int target = Math.min(keep, pager.getChildCount() - 1);
        pager.setPage(target, false);
        updateDots(target);
        if (!introPlayed) {
            introPlayed = true;
            playIntro();
        }
    }

    private View buildGridPage(List<AppEntry> list, int rows, int rowH) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(6), dp(8), 0);
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < COLS; c++) {
                int idx = r * COLS + c;
                View cell = idx < list.size() ? makeCell(list.get(idx), true) : new View(this);
                row.addView(cell, new LinearLayout.LayoutParams(0, rowH, 1f));
            }
            page.addView(row, new LinearLayout.LayoutParams(MATCH, rowH));
        }
        return page;
    }

    private View makeCell(final AppEntry e, boolean withLabel) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(withLabel ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER);
        cell.setPadding(0, withLabel ? dp(4) : 0, 0, 0);

        ImageView iv = new ImageView(this);
        iv.setImageBitmap(e.icon);
        cell.addView(iv, new LinearLayout.LayoutParams(dp(ICON_DP), dp(ICON_DP)));

        if (withLabel) {
            TextView tv = new TextView(this);
            tv.setText(e.label);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(2), 0, dp(2), 0);
            tv.setShadowLayer(dp(2), 0, dp(1), 0x99000000);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
            lp.topMargin = dp(5);
            cell.addView(tv, lp);
        }

        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(e, v);
            }
        });
        cell.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showMenu(v, e);
                return true;
            }
        });
        cell.setOnTouchListener(press);
        return cell;
    }

    private void rebuildDock() {
        dock.removeAllViews();
        for (AppEntry e : dockApps) {
            dock.addView(makeCell(e, false), new LinearLayout.LayoutParams(0, MATCH, 1f));
        }
    }

    private void updateDots(int selected) {
        int n = pager.getChildCount();
        dots.removeAllViews();
        for (int i = 0; i < n; i++) {
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Color.WHITE);
            dot.setBackground(g);
            dot.setAlpha(i == selected ? 1f : 0.35f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(7), dp(7));
            lp.setMargins(dp(4), 0, dp(4), 0);
            dots.addView(dot, lp);
        }
    }

    // ------------------------------------------------------------------ uygulama kitapligi

    private int groupOf(int category) {
        switch (category) {
            case ApplicationInfo.CATEGORY_SOCIAL:
                return 1;
            case ApplicationInfo.CATEGORY_GAME:
                return 2;
            case ApplicationInfo.CATEGORY_AUDIO:
            case ApplicationInfo.CATEGORY_VIDEO:
            case ApplicationInfo.CATEGORY_IMAGE:
                return 3;
            case ApplicationInfo.CATEGORY_NEWS:
            case ApplicationInfo.CATEGORY_MAPS:
            case ApplicationInfo.CATEGORY_PRODUCTIVITY:
                return 4;
            default:
                return 5;
        }
    }

    private View buildLibraryPage(int pw, int ph) {
        final String[] names = {"Son Eklenenler", "Sosyal", "Oyunlar", "Medya", "Üretkenlik", "Yardımcı Programlar"};
        List<List<AppEntry>> groups = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            groups.add(new ArrayList<AppEntry>());
        }
        List<AppEntry> recents = new ArrayList<>(all);
        Collections.sort(recents, new java.util.Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return Long.compare(b.installTime, a.installTime);
            }
        });
        groups.get(0).addAll(recents.subList(0, Math.min(4, recents.size())));
        for (AppEntry e : all) {
            groups.get(groupOf(e.category)).add(e);
        }

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Uygulama Kitaplığı");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(22), dp(2), 0, dp(8));
        page.addView(title, new LinearLayout.LayoutParams(MATCH, dp(42)));

        int gap = dp(14);
        int sideMax = (pw - dp(36) - gap) / 2;
        int labelH = dp(24);
        int vgap = dp(6);
        int availH = ph - dp(42);
        int side = Math.min(sideMax, (availH - 3 * (labelH + vgap)) / 3);

        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_HORIZONTAL);
            for (int c = 0; c < 2; c++) {
                int gi = r * 2 + c;
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.addView(buildCard(groups.get(gi), side), new LinearLayout.LayoutParams(side, side));

                TextView t = new TextView(this);
                t.setText(names[gi]);
                t.setTextColor(Color.WHITE);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                t.setGravity(Gravity.CENTER);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                col.addView(t, new LinearLayout.LayoutParams(side, labelH));

                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(WRAP, WRAP);
                if (c == 0) {
                    cp.rightMargin = gap;
                }
                row.addView(col, cp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(MATCH, WRAP);
            rp.bottomMargin = vgap;
            page.addView(row, rp);
        }
        return page;
    }

    private View buildCard(List<AppEntry> list, int side) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundedBg(0x3DFFFFFF, dp(24)));
        int pad = dp(11);
        int gap = dp(9);
        card.setPadding(pad, pad, pad, pad);
        int isz = (side - 2 * pad - gap) / 2;

        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 2; c++) {
                int idx = r * 2 + c;
                View v;
                if (idx < list.size()) {
                    final AppEntry e = list.get(idx);
                    ImageView iv = new ImageView(this);
                    iv.setImageBitmap(e.icon);
                    iv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            launch(e, view);
                        }
                    });
                    iv.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View view) {
                            showMenu(view, e);
                            return true;
                        }
                    });
                    iv.setOnTouchListener(press);
                    v = iv;
                } else {
                    v = new View(this);
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(isz, isz);
                if (c == 0) {
                    lp.rightMargin = gap;
                }
                row.addView(v, lp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(WRAP, WRAP);
            if (r == 0) {
                rp.bottomMargin = gap;
            }
            card.addView(row, rp);
        }
        return card;
    }

    // ------------------------------------------------------------------ arama (Spotlight)

    private void buildSearch() {
        searchOverlay = new FrameLayout(this);
        searchOverlay.setBackgroundColor(0xE6101018);
        searchOverlay.setClickable(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(60), dp(16), 0);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        searchBox = new EditText(this);
        searchBox.setHint("Ara");
        searchBox.setHintTextColor(0x99FFFFFF);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        searchBox.setSingleLine(true);
        searchBox.setBackground(roundedBg(0x33FFFFFF, dp(14)));
        searchBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.addView(searchBox, new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView cancel = new TextView(this);
        cancel.setText("İptal");
        cancel.setTextColor(0xFF0A84FF);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        cancel.setPadding(dp(14), dp(8), 0, dp(8));
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSearch();
            }
        });
        bar.addView(cancel, new LinearLayout.LayoutParams(WRAP, WRAP));
        col.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        ScrollView sv = new ScrollView(this);
        sv.setPadding(0, dp(12), 0, 0);
        sv.setClipToPadding(false);
        searchResults = new LinearLayout(this);
        searchResults.setOrientation(LinearLayout.VERTICAL);
        sv.addView(searchResults, new FrameLayout.LayoutParams(MATCH, WRAP));
        col.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        searchOverlay.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                fillResults(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void fillResults(String query) {
        searchResults.removeAllViews();
        String needle = query.trim().toLowerCase(tr);
        int shown = 0;
        for (AppEntry e : all) {
            if (!needle.isEmpty() && !e.label.toLowerCase(tr).contains(needle)) {
                continue;
            }
            searchResults.addView(makeRow(e));
            shown++;
            if (shown >= 40) {
                break;
            }
        }
        if (shown == 0) {
            TextView none = new TextView(this);
            none.setText("Sonuç yok");
            none.setTextColor(0x99FFFFFF);
            none.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, dp(40), 0, 0);
            searchResults.addView(none, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
    }

    private View makeRow(final AppEntry e) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(7), dp(4), dp(7));

        ImageView iv = new ImageView(this);
        iv.setImageBitmap(e.icon);
        row.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView tv = new TextView(this);
        tv.setText(e.label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp.leftMargin = dp(14);
        row.addView(tv, lp);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSearch();
                launch(e, v);
            }
        });
        return row;
    }

    private void openSearch() {
        if (searchOverlay.getVisibility() == View.VISIBLE) {
            return;
        }
        searchBox.setText("");
        fillResults("");
        searchOverlay.setAlpha(0f);
        searchOverlay.setTranslationY(-dp(28));
        searchOverlay.setVisibility(View.VISIBLE);
        searchOverlay.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(smooth).start();
        pager.animate().scaleX(0.94f).scaleY(0.94f).alpha(0f).setStartDelay(0).setDuration(240)
                .setInterpolator(smooth).start();
        dock.animate().alpha(0f).setStartDelay(0).setDuration(200).setInterpolator(smooth).start();
        dots.animate().alpha(0f).setStartDelay(0).setDuration(200).setInterpolator(smooth).start();
        searchBox.requestFocus();
        searchBox.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT);
                }
            }
        }, 150);
    }

    private void closeSearch() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        }
        pager.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0).setDuration(260)
                .setInterpolator(smooth).start();
        dock.animate().alpha(1f).setStartDelay(0).setDuration(260).setInterpolator(smooth).start();
        dots.animate().alpha(1f).setStartDelay(0).setDuration(260).setInterpolator(smooth).start();
        searchOverlay.animate().alpha(0f).translationY(-dp(20)).setDuration(180).withEndAction(new Runnable() {
            @Override
            public void run() {
                searchOverlay.setVisibility(View.GONE);
            }
        }).start();
    }

    // ------------------------------------------------------------------ uygulama islemleri

    private void launch(AppEntry e, View from) {
        if (editMode) {
            return;
        }
        if (e.internalId != 0) {
            openInternal(e.internalId, from);
            return;
        }
        try {
            Bundle opts = null;
            if (from != null) {
                opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.getWidth(), from.getHeight()).toBundle();
            }
            returning = true;
            startActivity(e.launch, opts);
        } catch (Exception ex) {
            returning = false;
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMenu(View anchor, final AppEntry e) {
        if (editMode || rootW == 0) {
            return;
        }
        dismissMenu(false);

        final FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(0x66000000);
        layer.setClickable(true);
        layer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissMenu(true);
            }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundedBg(0xF22C2C2E, dp(16)));
        final String[] labels = e.internalId != 0
                ? new String[]{"Ana Ekranı Düzenle"}
                : new String[]{"Uygulama Bilgisi", "Ana Ekranı Düzenle", "Uygulamayı Kaldır"};
        final int[] ids = e.internalId != 0 ? new int[]{1} : new int[]{0, 1, 2};
        for (int i = 0; i < labels.length; i++) {
            TextView t = new TextView(this);
            t.setText(labels[i]);
            t.setTextColor(ids[i] == 2 ? 0xFFFF453A : Color.WHITE);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding(dp(18), 0, dp(18), 0);
            final int idx = ids[i];
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dismissMenu(true);
                    menuAction(idx, e);
                }
            });
            card.addView(t, new LinearLayout.LayoutParams(dp(236), dp(48)));
            if (i < labels.length - 1) {
                View line = new View(this);
                line.setBackgroundColor(0x33FFFFFF);
                card.addView(line, new LinearLayout.LayoutParams(MATCH, 1));
            }
        }

        int cardW = dp(236);
        int cardH = dp(48) * labels.length + (labels.length - 1);
        int[] a1 = new int[2];
        int[] r1 = new int[2];
        anchor.getLocationOnScreen(a1);
        root.getLocationOnScreen(r1);
        int ax = a1[0] - r1[0];
        int ay = a1[1] - r1[1];
        float cx = ax + anchor.getWidth() / 2f;
        float x = Math.max(dp(12), Math.min(rootW - cardW - dp(12), cx - cardW / 2f));
        boolean below = ay + anchor.getHeight() + cardH + dp(16) < rootH - bottomInset - dp(8);
        float y = below ? ay + anchor.getHeight() + dp(10) : ay - cardH - dp(10);
        y = Math.max(dp(60), y);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cardW, cardH);
        lp.leftMargin = Math.round(x);
        lp.topMargin = Math.round(y);
        layer.addView(card, lp);
        card.setPivotX(Math.max(0, Math.min(cardW, cx - x)));
        card.setPivotY(below ? 0 : cardH);
        card.setScaleX(0.4f);
        card.setScaleY(0.4f);
        card.setAlpha(0f);

        root.addView(layer, new FrameLayout.LayoutParams(MATCH, MATCH));
        menuLayer = layer;
        layer.setAlpha(0f);
        layer.animate().alpha(1f).setDuration(160).start();
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(320)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private void dismissMenu(boolean animate) {
        final FrameLayout layer = menuLayer;
        if (layer == null) {
            return;
        }
        menuLayer = null;
        if (!animate) {
            root.removeView(layer);
            return;
        }
        layer.animate().alpha(0f).setDuration(140).withEndAction(new Runnable() {
            @Override
            public void run() {
                root.removeView(layer);
            }
        }).start();
    }

    private void menuAction(int idx, AppEntry e) {
        Uri uri = Uri.parse("package:" + e.pkg);
        try {
            if (idx == 0) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri));
            } else if (idx == 1) {
                enterEditMode();
            } else {
                startActivity(new Intent(Intent.ACTION_DELETE, uri));
            }
        } catch (Exception ex) {
            Toast.makeText(this, "Bu işlem yapılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadAppsAsync() {
        final int px = dp(ICON_DP);
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN, null);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);

                final List<AppEntry> out = new ArrayList<>();
                boolean[] seen = new boolean[4];
                for (ResolveInfo ri : infos) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) {
                        continue;
                    }
                    int internal = internalIdFor(pkg);
                    if (internal != 0) {
                        if (!seen[internal]) {
                            seen[internal] = true;
                            out.add(internalEntry(internal, px));
                        }
                        continue;
                    }
                    try {
                        String label = String.valueOf(ri.loadLabel(pm));
                        Bitmap icon = IconFactory.squircle(ri.loadIcon(pm), px);
                        Intent li = new Intent(Intent.ACTION_MAIN);
                        li.addCategory(Intent.CATEGORY_LAUNCHER);
                        li.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                        long installed = 0;
                        try {
                            installed = pm.getPackageInfo(pkg, 0).firstInstallTime;
                        } catch (Exception ignored) {
                        }
                        out.add(new AppEntry(label, pkg, li, ri.activityInfo.applicationInfo.category, installed, icon));
                    } catch (Throwable ignored) {
                    }
                }

                for (int id = 1; id <= 3; id++) {
                    if (!seen[id]) {
                        out.add(internalEntry(id, px));
                    }
                }
                final Collator collator = Collator.getInstance(tr);
                Collections.sort(out, new java.util.Comparator<AppEntry>() {
                    @Override
                    public int compare(AppEntry a, AppEntry b) {
                        return collator.compare(a.label, b.label);
                    }
                });
                final List<AppEntry> dockList = pickDock(pm, out);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        all.clear();
                        all.addAll(out);
                        dockApps.clear();
                        dockApps.addAll(dockList);
                        loaded = true;
                        rebuildPages();
                    }
                });
            }
        }, "load-apps").start();
    }

    /** Dock icin telefon, mesaj, tarayici ve kamera uygulamalarini bulur. */
    private List<AppEntry> pickDock(PackageManager pm, List<AppEntry> apps) {
        Intent[] probes = {
                new Intent(Intent.ACTION_DIAL, Uri.parse("tel:")),
                new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")),
                new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        };
        List<AppEntry> res = new ArrayList<>();
        for (Intent probe : probes) {
            AppEntry found = null;
            ResolveInfo best = pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY);
            if (best != null && best.activityInfo != null) {
                found = byPackage(apps, best.activityInfo.packageName, res);
            }
            if (found == null) {
                for (ResolveInfo ri : pm.queryIntentActivities(probe, 0)) {
                    found = byPackage(apps, ri.activityInfo.packageName, res);
                    if (found != null) {
                        break;
                    }
                }
            }
            if (found != null) {
                res.add(found);
            }
        }
        for (AppEntry e : apps) {
            if (res.size() >= 4) {
                break;
            }
            if (!res.contains(e)) {
                res.add(e);
            }
        }
        return res;
    }

    private AppEntry byPackage(List<AppEntry> apps, String pkg, List<AppEntry> exclude) {
        for (AppEntry e : apps) {
            if (e.pkg.equals(pkg) && !exclude.contains(e)) {
                return e;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ saat, pil, paket degisiklikleri

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String a = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(a)) {
                updateBattery(intent);
            } else if (Intent.ACTION_PACKAGE_ADDED.equals(a)
                    || Intent.ACTION_PACKAGE_REMOVED.equals(a)
                    || Intent.ACTION_PACKAGE_CHANGED.equals(a)) {
                loadAppsAsync();
            } else if (Intent.ACTION_TIME_TICK.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
                updateTime();
            } else {
                updateNetwork();
            }
        }
    };

    private void registerReceivers() {
        IntentFilter sys = new IntentFilter();
        sys.addAction(Intent.ACTION_TIME_TICK);
        sys.addAction(Intent.ACTION_TIME_CHANGED);
        sys.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        sys.addAction(Intent.ACTION_BATTERY_CHANGED);
        sys.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        sys.addAction(WifiManager.RSSI_CHANGED_ACTION);
        sys.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        sys.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        Intent sticky = registerReceiver(receiver, sys);
        if (sticky != null) {
            updateBattery(sticky);
        }

        IntentFilter pkgs = new IntentFilter();
        pkgs.addAction(Intent.ACTION_PACKAGE_ADDED);
        pkgs.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pkgs.addAction(Intent.ACTION_PACKAGE_CHANGED);
        pkgs.addDataScheme("package");
        registerReceiver(receiver, pkgs);
    }

    // ------------------------------------------------------------------ ag durumu

    private void startCellListener() {
        try {
            telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (telephony == null) {
                return;
            }
            if (telephony.getSimState() == TelephonyManager.SIM_STATE_ABSENT) {
                cellLevel = -1;
                return;
            }
            cellListener = new PhoneStateListener() {
                @Override
                public void onSignalStrengthsChanged(SignalStrength s) {
                    cellLevel = s != null ? s.getLevel() : -1;
                    updateNetwork();
                }
            };
            telephony.listen(cellListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
        } catch (Throwable t) {
            cellLevel = -1;
        }
    }

    @SuppressWarnings("deprecation")
    private void updateNetwork() {
        int wifi = -1;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected() && ni.getType() == ConnectivityManager.TYPE_WIFI) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                int rssi = wm.getConnectionInfo().getRssi();
                wifi = Math.max(0, Math.min(3, WifiManager.calculateSignalLevel(rssi, 4)));
            }
        } catch (Throwable ignored) {
        }
        statusBar.setNetwork(wifi, cellLevel);
    }

    // ------------------------------------------------------------------ ust paneller

    private void openPanel(boolean controlCenter) {
        if (controlCenter) {
            if (screen == null) {
                openScreen(new ControlCenter(this, this), null);
            }
            return;
        }
        try {
            Object sbm = getSystemService("statusbar");
            Class<?> c = Class.forName("android.app.StatusBarManager");
            c.getMethod(controlCenter ? "expandSettingsPanel" : "expandNotificationsPanel").invoke(sbm);
        } catch (Throwable t) {
            Toast.makeText(this, "Panel açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ duzenleme modu ve acilis animasyonu

    private final PathInterpolator smooth = new PathInterpolator(0.22f, 1f, 0.36f, 1f);
    private FrameLayout menuLayer;
    private boolean editMode;
    private boolean returning;
    private TextView doneBtn;
    private final List<ObjectAnimator> wiggles = new ArrayList<>();

    private void collectCells(ViewGroup g, List<View> out) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c.isLongClickable()) {
                out.add(c);
            } else if (c instanceof ViewGroup) {
                collectCells((ViewGroup) c, out);
            }
        }
    }

    private void enterEditMode() {
        if (editMode) {
            return;
        }
        editMode = true;
        doneBtn.setAlpha(0f);
        doneBtn.setVisibility(View.VISIBLE);
        doneBtn.animate().alpha(1f).setDuration(200).start();
        startWiggle();
    }

    private void exitEditMode() {
        editMode = false;
        doneBtn.setVisibility(View.GONE);
        stopWiggle();
    }

    private void startWiggle() {
        stopWiggle();
        List<View> cells = new ArrayList<>();
        collectCells(pager, cells);
        collectCells(dock, cells);
        for (View v : cells) {
            ObjectAnimator o = ObjectAnimator.ofFloat(v, View.ROTATION, -2.3f, 2.3f);
            o.setDuration(95 + (long) (Math.random() * 45));
            o.setRepeatCount(ValueAnimator.INFINITE);
            o.setRepeatMode(ValueAnimator.REVERSE);
            o.setStartDelay((long) (Math.random() * 80));
            o.start();
            wiggles.add(o);
        }
    }

    private void stopWiggle() {
        for (ObjectAnimator o : wiggles) {
            o.cancel();
            Object t = o.getTarget();
            if (t instanceof View) {
                ((View) t).setRotation(0f);
            }
        }
        wiggles.clear();
    }

    private void playIntro() {
        List<View> cells = new ArrayList<>();
        if (pager.getChildCount() > 0 && pager.getChildAt(0) instanceof ViewGroup) {
            collectCells((ViewGroup) pager.getChildAt(0), cells);
        }
        int n = 0;
        for (View v : cells) {
            v.setAlpha(0f);
            v.setScaleX(0.55f);
            v.setScaleY(0.55f);
            v.setTranslationY(dp(18));
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                    .setStartDelay(Math.min(n, 20) * 22L).setDuration(420)
                    .setInterpolator(new OvershootInterpolator(1.5f)).start();
            n++;
        }
        dock.setTranslationY(dp(120));
        dock.animate().translationY(0f).setDuration(520).setInterpolator(new OvershootInterpolator(0.9f)).start();
    }

    private void playReturn() {
        View[] vs = {pager, dock, dots};
        for (View v : vs) {
            v.animate().cancel();
            v.setScaleX(1.14f);
            v.setScaleY(1.14f);
            v.setAlpha(0f);
            v.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0).setDuration(380)
                    .setInterpolator(smooth).start();
        }
    }

    // ------------------------------------------------------------------ kendi uygulamalarimiz

    private ScreenBase screen;

    private int internalIdFor(String pkg) {
        if (pkg.equals("com.android.settings")) {
            return 1;
        }
        if (pkg.equals("com.miui.calculator") || pkg.equals("com.android.calculator2")
                || pkg.equals("com.google.android.calculator")) {
            return 2;
        }
        if (pkg.equals("com.miui.notes")) {
            return 3;
        }
        return 0;
    }

    private AppEntry internalEntry(int id, int px) {
        String label = id == 1 ? "Ayarlar" : id == 2 ? "Hesap Makinesi" : "Notlar";
        return new AppEntry(label, "ilauncher.internal." + id, null, ApplicationInfo.CATEGORY_UNDEFINED, 0L,
                OwnIcons.make(this, id, px), id);
    }

    @Override
    public int bottomInset() {
        return bottomInset;
    }

    @Override
    public boolean launchIntent(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            returning = true;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public void openInternal(int id, View from) {
        ScreenBase s;
        if (id == 1) {
            s = new SettingsScreen(this, this);
        } else if (id == 2) {
            s = new CalculatorScreen(this, this);
        } else {
            s = new NotesScreen(this, this);
        }
        openScreen(s, from);
    }

    private void openScreen(ScreenBase s, View from) {
        if (screen != null) {
            return;
        }
        screen = s;
        float px = rootW / 2f;
        float py = rootH / 2f;
        if (from != null) {
            int[] a = new int[2];
            int[] r = new int[2];
            from.getLocationOnScreen(a);
            root.getLocationOnScreen(r);
            px = a[0] - r[0] + from.getWidth() / 2f;
            py = a[1] - r[1] + from.getHeight() / 2f;
        }
        root.addView(s, root.indexOfChild(statusBar), new FrameLayout.LayoutParams(MATCH, MATCH));
        statusBar.setDark(s.darkStatus());

        s.setAlpha(0f);
        if (s.translucent()) {
            s.setScaleX(1.06f);
            s.setScaleY(1.06f);
            s.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(300)
                    .setInterpolator(smooth).start();
            return;
        }
        float iw = from != null ? from.getWidth() : dp(60);
        float ih = from != null ? from.getHeight() : dp(60);
        RectF ir = new RectF(px - iw / 2f, py - ih / 2f, px + iw / 2f, py + ih / 2f);
        s.setMorphGeometry(rootW, rootH, ir, Math.min(iw, ih) * 0.2237f);
        s.setMorph(0f);
        s.animateMorph(1f, 520, Fx.SPRING_MILD, null);
        View[] vs = {pager, dock, dots};
        for (View v : vs) {
            v.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f).setStartDelay(0).setDuration(320)
                    .setInterpolator(smooth).start();
        }
    }

    @Override
    public void closeScreen(final ScreenBase s) {
        if (screen != s) {
            return;
        }
        screen = null;
        s.onClosing();
        statusBar.setDark(false);
        s.animate().cancel();
        if (!s.translucent()) {
            View[] vs = {pager, dock, dots};
            for (View v : vs) {
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0).setDuration(360)
                        .setInterpolator(smooth).start();
            }
            s.animateMorph(0f, 380, smooth, new Runnable() {
                @Override
                public void run() {
                    root.removeView(s);
                }
            });
            return;
        }
        s.animate().setStartDelay(0).setDuration(320).setInterpolator(smooth)
                .alpha(0f).scaleX(1.06f).scaleY(1.06f).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(s);
                    }
                }).start();
    }

    private void updateTime() {
        statusBar.setTime(new SimpleDateFormat("H:mm", Locale.getDefault()).format(new Date()));
    }

    private void updateBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
        statusBar.setBattery(pct, charging);
        island.setBattery(pct, charging);
    }
}
